function toggleAssistant(){
  const panel=document.getElementById('assistantPanel');
  if(!panel) return;
  panel.classList.toggle('open');
  if(panel.classList.contains('open')){
    const input=document.getElementById('assistantInput');
    if(input) setTimeout(()=>input.focus(),150);
    const body=document.getElementById('assistantBody');
    if(body) body.scrollTop=body.scrollHeight;
  }
}
function askSuggestion(q){
  const input=document.getElementById('assistantInput');
  if(!input) return;
  input.value=q;
  sendAssistant();
}
function escapeHtml(s){return String(s||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function nowTime(){
  try{ return new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}); }
  catch(e){ return ''; }
}
function appendMessage(body, role, html, time){
  const avatar = role==='user' ? 'You' : 'TS';
  const wrap=document.createElement('div');
  wrap.className='msg '+role;
  wrap.innerHTML = `<div class="msg-avatar">${avatar}</div><div class="msg-bubble">${html}<div class="msg-time">${time||nowTime()}</div></div>`;
  body.appendChild(wrap);
  body.scrollTop=body.scrollHeight;
  return wrap;
}
async function sendAssistant(){
  const input=document.getElementById('assistantInput');
  const body=document.getElementById('assistantBody');
  if(!input||!body) return;
  const q=input.value.trim();
  if(!q) return;
  appendMessage(body,'user', escapeHtml(q));
  input.value='';
  input.focus();

  const typing=document.createElement('div');
  typing.className='msg bot typing-msg';
  typing.innerHTML='<div class="msg-avatar">TS</div><div class="msg-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>';
  body.appendChild(typing);
  body.scrollTop=body.scrollHeight;

  try{
    const r=await fetch((window.ROOT_PATH||'')+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});
    let d={};
    try{ d=await r.json(); }catch(_){ d={answer:'Assistant returned an invalid response.'}; }
    typing.remove();
    const modeLabel = d.mode==='gemini' ? 'Gemini AI' : 'Local KYC data';
    const answerHtml = escapeHtml(d.answer||'No answer returned.').replace(/\n/g,'<br>');
    const bubble = appendMessage(body,'bot', answerHtml);
    bubble.querySelector('.msg-bubble').insertAdjacentHTML('beforeend', `<span class="msg-mode">Source: ${escapeHtml(modeLabel)}</span>`);
  }catch(e){
    typing.remove();
    appendMessage(body,'bot','I\'m running in local KYC mode right now. Please ask about case status, documents, queues, risk, screening or next actions.');
  }
  body.scrollTop=body.scrollHeight;
}
document.addEventListener('keydown',e=>{
  if(e.key==='Enter' && document.activeElement && document.activeElement.id==='assistantInput'){
    e.preventDefault();
    sendAssistant();
  }
  if(e.key==='Escape'){
    const panel=document.getElementById('assistantPanel');
    if(panel && panel.classList.contains('open')) panel.classList.remove('open');
  }
});

async function runAgents(caseId){
  const box=document.getElementById('agentRunResult');
  if(box){box.innerHTML='<div><span>Status</span><b>Running AI agents...</b></div><div><span>Case</span><b>'+escapeHtml(caseId)+'</b></div><div><span>Trace</span><b>Creating</b></div><div><span>Decision</span><b>Processing</b></div>';}
  try{
    const r=await fetch((window.ROOT_PATH||'')+'/api/agents/'+encodeURIComponent(caseId)+'/run',{method:'POST'});
    const d=await r.json();
    if(!r.ok){throw new Error(d.error||'Agent run failed');}
    if(box){box.innerHTML=`<div><span>Run ID</span><b>${escapeHtml(d.run_id)}</b></div><div><span>Completed Agents</span><b>${d.completed_agents}/${d.agent_count}</b></div><div><span>Decision</span><b>${escapeHtml(d.decision)}</b></div><div><span>Trace</span><b>Saved in ai_agents/traces</b></div>`;}
    const live=document.getElementById('agentTimelineLive');
    if(live&&Array.isArray(d.workflow)){
      live.innerHTML='<div class="trace-note">Master Orchestrator completed the end-to-end KYC agent workflow.</div>'+d.workflow.map((a,i)=>`<div class="timeline-card"><div class="num">${i+1}</div><div><h4>${escapeHtml(a.agent_name||a.name)}</h4><p><b>${escapeHtml(a.stage)}</b> · ${escapeHtml(a.status)} · Confidence ${escapeHtml(a.confidence)}%</p><p>${escapeHtml(a.finding)}</p></div></div>`).join('');
    }
  }catch(e){
    if(box){box.innerHTML='<div><span>Status</span><b>Agent run failed</b></div><div><span>Reason</span><b>'+escapeHtml(e.message)+'</b></div>';}
  }
}
