TrustShield data and folder guide

1. data/
   Stores demo CSV/JSON/TXT datasets used by the KYC app.
   New customer registrations update customers.csv and kyc_documents.csv.

2. uploads/demo_customer_docs/
   Contains synthetic sample KYC document images for demo customers.

3. uploads/customer_uploaded_documents/
   Customer portal uploads are saved here by customer_id/case_id/upload_batch_id.

4. uploads/staff_uploaded_documents/
   Staff manual uploads are saved here by customer_id/case_id/upload_batch_id.

5. outputs/
   Stores agent traces, decision logs, audit logs, and customer/staff notification text files.

6. reports/
   Stores generated audit reports and KYC evidence packs.
