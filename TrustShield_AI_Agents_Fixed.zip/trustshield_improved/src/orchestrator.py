"""
Master KYC Orchestrator — coordinates all specialist agents.
Improvements:
  • Structured logging instead of print statements
  • Per-step error isolation (one agent failure doesn't crash the pipeline)
  • Deduplicates duplicate decision_workflow key in decision_log
  • Respects warning_reasons from improved guardrails
  • Writes per-case markdown summary alongside the trace JSON
  • Consistent timestamp format across all outputs
"""
import os
import json
import logging
from datetime import datetime
from src.config import FILES, DIRS
from src.constants import *
from src.pii_masking import mask_customer_dict, mask_pan, mask_aadhaar, mask_mobile, mask_bank_account, mask_address
from src.data_loader import get_case_details, load_compliance_rules, load_kyc_policy, update_case_status
from src.document_checks import run_simulated_ocr_checks
from src.risk_engine import calculate_case_risk
from src.guardrails import validate_guardrails
from src.gemini_reasoning import run_gemini_reasoning, generate_fallback_reasoning
from src.notification_generator import generate_all_notification_drafts
from src.agents import *
import src.audit_trail as audit_trail

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _safe_agent(fn, *args, fallback_name="Unknown Agent", **kwargs):
    """Run an agent function; return a safe failure finding on exception."""
    try:
        return fn(*args, **kwargs)
    except Exception as e:
        logger.exception("Agent %s failed: %s", fallback_name, e)
        return AgentFinding(
            agent_name=fallback_name,
            status="Warning",
            finding="Agent encountered an internal error — result unavailable",
            evidence=str(e)[:200],
            confidence=0.0,
            risk_impact=0,
        )


def _token_similarity(a: str, b: str) -> float:
    """Lightweight token overlap score for name/address cross-checks."""
    import re
    a_tokens = set(re.findall(r"\w+", str(a or "").lower()))
    b_tokens = set(re.findall(r"\w+", str(b or "").lower()))
    if not a_tokens or not b_tokens:
        return 1.0 if not a_tokens and not b_tokens else 0.0
    return len(a_tokens & b_tokens) / max(1, len(a_tokens | b_tokens))


def _add_doc_issue(issue_map: dict, doc_type: str, issue: str) -> None:
    doc_type = str(doc_type or "Document").strip() or "Document"
    issue_map.setdefault(doc_type, [])
    if issue and issue not in issue_map[doc_type]:
        issue_map[doc_type].append(issue)


def build_document_crosscheck_summary(case_details: dict, ocr_results: list) -> dict:
    """
    Counts how many uploaded documents have KYC cross-check discrepancies.
    Business rule implemented for this project:
      • 0 discrepant documents  -> eligible for auto approval
      • 1-2 discrepant documents -> manual/human review + notify customer & staff
      • >2 discrepant documents -> auto reject + notify customer & staff

    Checks included: photo/selfie match, liveness, name, DOB, address, OCR confidence,
    quality, tampering, expired/invalid document status.
    """
    customer = case_details.get("customer", {}) or {}
    issue_map: dict[str, list[str]] = {}

    # 1) OCR/result findings from document intelligence
    for r in ocr_results or []:
        doc_type = r.get("document_type", "Document")
        for issue in (r.get("findings") or r.get("issues") or []):
            _add_doc_issue(issue_map, doc_type, str(issue))
        status = str(r.get("status") or r.get("overall_status") or "").lower()
        if "fail" in status:
            _add_doc_issue(issue_map, doc_type, "Document validation failed")

    # 2) Direct field-level cross-check against customer profile
    profile_name = customer.get("full_name", "")
    profile_dob = str(customer.get("dob", "")).strip()
    profile_address = customer.get("address", "")
    for d in case_details.get("documents", []) or []:
        doc_type = d.get("document_type", "Document")

        doc_name = d.get("document_name_value", "")
        if doc_name and profile_name and _token_similarity(doc_name, profile_name) < 0.65:
            _add_doc_issue(issue_map, doc_type, f"Name mismatch with registration profile: '{doc_name}' vs '{profile_name}'")

        doc_dob = str(d.get("document_dob_value", "")).strip()
        if doc_dob and profile_dob and doc_dob != profile_dob:
            _add_doc_issue(issue_map, doc_type, f"DOB mismatch with registration profile: '{doc_dob}' vs '{profile_dob}'")

        doc_address = d.get("document_address_value", "")
        if doc_address and profile_address and _token_similarity(doc_address, profile_address) < 0.45:
            _add_doc_issue(issue_map, doc_type, f"Address mismatch with registration profile: '{doc_address}' vs '{profile_address}'")

        status = str(d.get("document_status", "")).lower()
        if status in ("failed", "rejected", "invalid", "expired"):
            _add_doc_issue(issue_map, doc_type, f"Document status is {d.get('document_status')}")

        quality = str(d.get("quality_status", "")).lower()
        if quality in ("blurred", "incomplete", "failed", "poor"):
            _add_doc_issue(issue_map, doc_type, f"Document quality issue: {d.get('quality_status')}")

        tamper = str(d.get("tampering_indicator", "")).lower()
        if tamper not in ("not detected", "none", "0", "false", "nan", ""):
            _add_doc_issue(issue_map, doc_type, "Tampering suspected")

        try:
            if float(d.get("confidence_score", 1.0) or 1.0) < 0.75:
                _add_doc_issue(issue_map, doc_type, "Low OCR confidence below 75%")
        except Exception:
            pass

    # 2B) Cross-document pairwise consistency — documents vs. each other
    #     (not just each document vs. the registration profile). Catches
    #     internally-inconsistent identity documents (e.g. PAN name differs
    #     from Aadhaar name) even when each individually passes the profile check.
    active_docs = [d for d in (case_details.get("documents", []) or [])
                    if str(d.get("document_status", "")).lower() != "missing"]
    for i in range(len(active_docs)):
        for j in range(i + 1, len(active_docs)):
            d1, d2 = active_docs[i], active_docs[j]
            t1, t2 = d1.get("document_type", "Document"), d2.get("document_type", "Document")

            n1 = str(d1.get("document_name_value", "") or "")
            n2 = str(d2.get("document_name_value", "") or "")
            if n1 and n2 and _token_similarity(n1, n2) == 0.0:
                _add_doc_issue(issue_map, t1, f"Name conflicts with {t2}: '{n1}' vs '{n2}'")
                _add_doc_issue(issue_map, t2, f"Name conflicts with {t1}: '{n2}' vs '{n1}'")

            dob1 = str(d1.get("document_dob_value", "") or "").strip()
            dob2 = str(d2.get("document_dob_value", "") or "").strip()
            if dob1 and dob2 and dob1 != dob2:
                _add_doc_issue(issue_map, t1, f"DOB conflicts with {t2}: '{dob1}' vs '{dob2}'")
                _add_doc_issue(issue_map, t2, f"DOB conflicts with {t1}: '{dob2}' vs '{dob1}'")

    # 2C) Cross-document address consistency
    for i in range(len(active_docs)):
        for j in range(i + 1, len(active_docs)):
            d1, d2 = active_docs[i], active_docs[j]
            t1, t2 = d1.get("document_type", "Document"), d2.get("document_type", "Document")
            a1 = str(d1.get("document_address_value", "") or "")
            a2 = str(d2.get("document_address_value", "") or "")
            if a1 and a2 and _token_similarity(a1, a2) < 0.45:
                _add_doc_issue(issue_map, t1, f"Address differs from {t2}")
                _add_doc_issue(issue_map, t2, f"Address differs from {t1}")


    selfie = case_details.get("selfie_verification", {}) or {}
    if not selfie or not selfie.get("selfie_available", 0):
        _add_doc_issue(issue_map, "Selfie / Photo", "Selfie not available for face match")
    else:
        if str(selfie.get("liveness_check", "")).lower() == "failed":
            _add_doc_issue(issue_map, "Selfie / Photo", "Liveness check failed")
        try:
            match_score = float(selfie.get("selfie_match_score", 1.0) or 1.0)
            if match_score < 0.50:
                _add_doc_issue(issue_map, "Selfie / Photo", f"Photo match failed: selfie/document face similarity {match_score*100:.0f}%")
            elif match_score < 0.75:
                _add_doc_issue(issue_map, "Selfie / Photo", f"Photo match requires manual review: similarity {match_score*100:.0f}%")
        except Exception:
            pass

    issue_map = {k: v for k, v in issue_map.items() if v}
    all_issues = [f"{doc}: {issue}" for doc, issues in issue_map.items() for issue in issues]
    return {
        "document_discrepancy_count": len(issue_map),
        "discrepant_documents": sorted(issue_map.keys()),
        "document_issue_map": issue_map,
        "all_document_discrepancies": all_issues,
    }


def build_discrepancy_decision(
    case_details: dict,
    ocr_results: list,
    risk_res: dict,
    guardrail_res: dict,
) -> dict:
    """
    Converts raw AI-agent/risk outputs into a business workflow decision.

    Precedence:
      SANCTIONS / HARD BLOCK  → Manager Approval Required
      Missing / invalid docs  → More Documents Required
      High/Critical risk       → Manual Review Required (or Manager Approval if blocked)
      Medium / any discrepancy → Manual Review Required
      Clean low-risk           → Auto Approved
    """
    discrepancies: list[str] = []
    high_triggers: list[str] = []
    manual_review_triggers: list[str] = []

    crosscheck_summary = build_document_crosscheck_summary(case_details, ocr_results)
    document_discrepancy_count = int(crosscheck_summary.get("document_discrepancy_count", 0))
    discrepant_documents = crosscheck_summary.get("discrepant_documents", [])
    document_issue_map = crosscheck_summary.get("document_issue_map", {})

    # OCR discrepancies
    for r in ocr_results or []:
        doc_type = r.get("document_type", "Document")
        status = str(r.get("overall_status", r.get("status", "")))
        issues = r.get("issues", []) or r.get("findings", []) or []
        if isinstance(issues, str):
            issues = [issues]
        for issue in issues:
            discrepancies.append(f"{doc_type}: {issue}")
            text = str(issue).lower()
            if any(k in text for k in ["tamper", "mismatch", "expired", "failed", "sanction", "duplicate", "liveness"]):
                manual_review_triggers.append(f"{doc_type}: {issue}")
        if "fail" in status.lower():
            manual_review_triggers.append(f"{doc_type}: validation failed")

    # Add consolidated document/photo cross-check findings.
    for issue in crosscheck_summary.get("all_document_discrepancies", []):
        if issue not in discrepancies:
            discrepancies.append(issue)
            manual_review_triggers.append(issue)

    # Document hard failures
    for d in case_details.get("documents", []):
        doc_type = d.get("document_type", "Document")
        tamper = str(d.get("tampering_indicator", "")).lower()
        if tamper not in ("not detected", "none", "0", "false", "nan", ""):
            high_triggers.append(f"{doc_type}: tampering suspected")
        if str(d.get("document_status", "")).lower() in ("failed", "rejected", "invalid"):
            manual_review_triggers.append(f"{doc_type}: document status {d.get('document_status')}")
        try:
            if float(d.get("confidence_score", 1)) < 0.75:
                manual_review_triggers.append(f"{doc_type}: low OCR confidence")
        except Exception:
            pass

    # Identity hard failures
    selfie = case_details.get("selfie_verification", {}) or {}
    if selfie.get("liveness_check") == "Failed":
        high_triggers.append("Selfie liveness check failed")
    try:
        match_score = float(selfie.get("selfie_match_score", 1))
        if match_score < 0.50:
            high_triggers.append("Selfie face match score below threshold")
        elif match_score < 0.75:
            manual_review_triggers.append("Selfie match score requires manual review")
    except Exception:
        pass

    # Watchlist hard failures
    fraud = case_details.get("fraud_watchlist", {}) or {}
    sanctions = case_details.get("sanctions_watchlist", {}) or {}
    pep = case_details.get("pep_watchlist", {}) or {}
    adverse = case_details.get("adverse_media", {}) or {}

    if fraud.get("duplicate_pan", 0):
        high_triggers.append("Duplicate PAN detected")
    if fraud.get("synthetic_identity_signal", 0):
        high_triggers.append("Synthetic identity signal detected")
    if sanctions.get("sanctions_match", 0):
        high_triggers.append("Sanctions watchlist match detected")
    if pep.get("pep_match", 0):
        manual_review_triggers.append("PEP match — Enhanced Due Diligence required")
    if adverse.get("adverse_media_match", 0):
        manual_review_triggers.append("Adverse media match — compliance review required")

    risk_level = risk_res.get("risk_level", "Low")
    score = int(risk_res.get("risk_score", 0))
    blocked = guardrail_res.get("status") == "Blocked"

    # Missing / invalid documents → Re-upload queue
    missing_or_invalid = any(
        str(d.get("document_status", "")).lower() in ("missing", "invalid", "failed", "rejected")
        for d in case_details.get("documents", [])
    )

    if missing_or_invalid:
        return {
            "discrepancy_level": "Medium",
            "system_action": "Request Document Re-upload",
            "final_case_status": "More Documents Required",
            "customer_visible_status": "Document Re-upload Required",
            "customer_message": "Additional or corrected documents are required. Please re-upload via the Document Upload section.",
            "staff_required_action": "Notify customer to re-upload missing / invalid documents.",
            "decision_reason": "Mandatory document issue detected. Routed to re-upload queue.",
            "high_discrepancy_triggers": high_triggers,
            "manual_review_triggers": manual_review_triggers,
            "all_discrepancies": discrepancies,
            "document_discrepancy_count": document_discrepancy_count,
            "discrepant_documents": discrepant_documents,
            "document_issue_map": document_issue_map,
            "auto_reject": False,
            "auto_approved": False,
            "manual_review": False,
            "risk_score": score,
            "risk_level": risk_level,
        }

    # Document cross-check business rule after upload:
    # 1-2 discrepant documents -> Manual Review; more than 2 -> Auto Reject.
    # Critical policy blocks/sanctions still use the compliance escalation branch below.
    if document_discrepancy_count > 2 and not blocked and not sanctions.get("sanctions_match", 0):
        return {
            "discrepancy_level": "High",
            "system_action": "Auto Reject",
            "final_case_status": "Rejected",
            "customer_visible_status": "Rejected",
            "customer_message": "Your KYC could not be approved because discrepancies were found in more than two submitted documents. Please contact support if you believe this needs review.",
            "staff_required_action": "Case auto-rejected by document cross-check rule. Review the evidence pack only if an exception is requested.",
            "decision_reason": f"Document cross-check found discrepancies in {document_discrepancy_count} verification items: {', '.join(discrepant_documents)}. Business rule: more than two document discrepancies = auto reject.",
            "high_discrepancy_triggers": high_triggers + crosscheck_summary.get("all_document_discrepancies", []),
            "manual_review_triggers": manual_review_triggers,
            "all_discrepancies": discrepancies,
            "document_discrepancy_count": document_discrepancy_count,
            "discrepant_documents": discrepant_documents,
            "document_issue_map": document_issue_map,
            "auto_reject": True,
            "auto_approved": False,
            "manual_review": False,
            "risk_score": score,
            "risk_level": risk_level,
        }

    if 1 <= document_discrepancy_count <= 2 and not blocked and not sanctions.get("sanctions_match", 0):
        return {
            "discrepancy_level": "Medium",
            "system_action": "Pending Human Review",
            "final_case_status": "Manual Review Required",
            "customer_visible_status": "Under Manual Review",
            "customer_message": "Your KYC documents have been received. One or two document discrepancies were found, so the case has been sent to the KYC staff for manual review.",
            "staff_required_action": "Review the specific discrepant document(s), contact customer for clarification/re-upload if required, then approve or reject.",
            "decision_reason": f"Document cross-check found discrepancies in {document_discrepancy_count} verification item(s): {', '.join(discrepant_documents)}. Business rule: one or two document discrepancies = manual review.",
            "high_discrepancy_triggers": high_triggers,
            "manual_review_triggers": manual_review_triggers + crosscheck_summary.get("all_document_discrepancies", []),
            "all_discrepancies": discrepancies,
            "document_discrepancy_count": document_discrepancy_count,
            "discrepant_documents": discrepant_documents,
            "document_issue_map": document_issue_map,
            "auto_reject": False,
            "auto_approved": False,
            "manual_review": True,
            "risk_score": score,
            "risk_level": risk_level,
        }

    if blocked or risk_level in ("High", "Critical") or high_triggers:
        is_critical = risk_level == "Critical" or blocked or sanctions.get("sanctions_match", 0)
        return {
            "discrepancy_level": "High",
            "system_action": "Manager Approval Required" if is_critical else "Pending Human Review",
            "final_case_status": "Manager Approval Required" if is_critical else "Manual Review Required",
            "customer_visible_status": "Under Enhanced Review",
            "customer_message": "Your KYC is under enhanced review. We will notify you once completed.",
            "staff_required_action": "Review evidence pack, validate documents, escalate or approve with justification.",
            "decision_reason": "High discrepancy or policy guardrail detected. Routed to human/manager review.",
            "high_discrepancy_triggers": high_triggers,
            "manual_review_triggers": manual_review_triggers,
            "all_discrepancies": discrepancies,
            "document_discrepancy_count": document_discrepancy_count,
            "discrepant_documents": discrepant_documents,
            "document_issue_map": document_issue_map,
            "auto_reject": False,
            "auto_approved": False,
            "manual_review": True,
            "risk_score": score,
            "risk_level": risk_level,
        }

    if risk_level == "Medium" or manual_review_triggers or discrepancies:
        return {
            "discrepancy_level": "Low",
            "system_action": "Pending Human Review",
            "final_case_status": "Manual Review Required",
            "customer_visible_status": "Under Review",
            "customer_message": "Your KYC is under manual review. We will notify you if additional documents are needed.",
            "staff_required_action": "KYC staff must review discrepancies and take final action.",
            "decision_reason": "Discrepancy detected. Routed to pending human review queue.",
            "high_discrepancy_triggers": high_triggers,
            "manual_review_triggers": manual_review_triggers,
            "all_discrepancies": discrepancies,
            "document_discrepancy_count": document_discrepancy_count,
            "discrepant_documents": discrepant_documents,
            "document_issue_map": document_issue_map,
            "auto_reject": False,
            "auto_approved": False,
            "manual_review": True,
            "risk_score": score,
            "risk_level": risk_level,
        }

    # Clean — Auto Approved
    return {
        "discrepancy_level": "None",
        "system_action": "Auto Approved",
        "final_case_status": "Approved",
        "customer_visible_status": "Approved",
        "customer_message": "Your KYC has been verified successfully and is now approved.",
        "staff_required_action": "No action required. Staff can still escalate for manager review if needed.",
        "decision_reason": "No discrepancy detected. Low-risk clean case auto-approved by TrustShield AI.",
        "high_discrepancy_triggers": [],
        "manual_review_triggers": [],
        "all_discrepancies": [],
        "document_discrepancy_count": document_discrepancy_count,
        "discrepant_documents": discrepant_documents,
        "document_issue_map": document_issue_map,
        "auto_reject": False,
        "auto_approved": True,
        "manual_review": False,
        "risk_score": score,
        "risk_level": risk_level,
    }


def run_master_orchestrator(case_id: str, api_key: str = None) -> dict:
    """
    Executes the entire KYC multi-agent compliance pipeline.
    Returns a fully structured result dict consumed by app.py.
    """
    logger.info("Orchestrator: starting pipeline for %s", case_id)

    # ── 1. Load data ─────────────────────────────────────────────────
    case_details = get_case_details(case_id)
    if not case_details:
        return {"success": False, "message": f"Case ID {case_id} not found."}

    rules = load_compliance_rules()
    policy_text = load_kyc_policy()
    cust = case_details["customer"]
    cust_id = cust["customer_id"]

    # ── 2. OCR Simulation ────────────────────────────────────────────
    ocr_results = []
    for doc in case_details["documents"]:
        try:
            ocr_results.append(run_simulated_ocr_checks(doc, cust, rules))
        except Exception as e:
            logger.warning("OCR failed for %s: %s", doc.get("document_type"), e)

    # ── 3. Secure masked context ─────────────────────────────────────
    masked_cust = mask_customer_dict(cust)
    masked_docs = []
    for d in case_details["documents"]:
        md = d.copy()
        md["id_number"] = (
            mask_pan(d["id_number"]) if d.get("document_type") == "PAN"
            else mask_aadhaar(d["id_number"]) if d.get("document_type") == "Aadhaar"
            else d.get("id_number", "")
        )
        md["document_address_value"] = mask_address(md.get("document_address_value", ""))
        masked_docs.append(md)

    secure_context = {
        "case_id": case_id,
        "customer_id": cust_id,
        "customer_profile": masked_cust,
        "documents": masked_docs,
        "selfie_verification": case_details["selfie_verification"].copy(),
        "transactions": case_details["transactions"][:20],  # cap for context size
        "fraud_watchlist": case_details["fraud_watchlist"].copy(),
        "sanctions_watchlist": case_details["sanctions_watchlist"].copy(),
        "pep_watchlist": case_details["pep_watchlist"].copy(),
        "adverse_media": case_details["adverse_media"].copy(),
        "ocr_sim_results": ocr_results,
        "policy_rules": rules,
        "case_history": case_details.get("case_history", [])[-5:],  # last 5 events
        "policy_knowledge_snippet": policy_text[:1500],
    }

    # ── 4. Risk scoring & guardrails ─────────────────────────────────
    risk_res = calculate_case_risk(case_details, rules)
    risk_result_model = RiskResult(**risk_res)

    guardrail_res = validate_guardrails(case_details, risk_res, rules)
    # GuardrailResult may not have warning_reasons — add default
    guardrail_res.setdefault("warning_reasons", [])
    guardrail_result_model = GuardrailResult(**{
        k: v for k, v in guardrail_res.items() if k in GuardrailResult.model_fields
    })

    # ── 5. Business workflow decision ───────────────────────────────
    decision_workflow = build_discrepancy_decision(case_details, ocr_results, risk_res, guardrail_res)

    # ── 6. Specialist agents ─────────────────────────────────────────
    agent_findings: list[AgentFinding] = []

    agent_findings.append(_safe_agent(run_document_intelligence_agent,  case_details, rules,        fallback_name=AGENT_DOC_INTEL))
    agent_findings.append(_safe_agent(run_cross_document_consistency_agent, case_details, rules,     fallback_name=AGENT_CROSS_DOC))
    agent_findings.append(_safe_agent(run_identity_verification_agent,  case_details, rules,        fallback_name=AGENT_IDENTITY_VER))
    agent_findings.append(_safe_agent(run_compliance_rag_agent,          case_details, rules,        fallback_name=AGENT_COMPLIANCE_RAG))
    agent_findings.append(_safe_agent(run_aml_sanctions_agent,           case_details, rules,        fallback_name=AGENT_AML_SANCTIONS))
    agent_findings.append(_safe_agent(run_pep_screening_agent,           case_details, rules,        fallback_name=AGENT_PEP_SCREENING))
    agent_findings.append(_safe_agent(run_adverse_media_agent,           case_details, rules,        fallback_name=AGENT_ADVERSE_MEDIA))
    agent_findings.append(_safe_agent(run_financial_profiling_agent,     case_details, rules,        fallback_name=AGENT_FINANCIAL_PROFILE))
    agent_findings.append(_safe_agent(run_fraud_intelligence_agent,      case_details, rules,        fallback_name=AGENT_FRAUD_INTEL))
    agent_findings.append(_safe_agent(run_transaction_risk_agent,        case_details, rules,        fallback_name=AGENT_TX_RISK))
    agent_findings.append(_safe_agent(run_risk_intelligence_agent,       case_details, risk_res,     fallback_name=AGENT_RISK_INTEL))
    agent_findings.append(_safe_agent(run_guardrail_agent,               case_details, guardrail_res, fallback_name=AGENT_GUARDRAIL))

    # Serialise for Gemini prompt
    secure_context_str = json.dumps(secure_context, indent=2, default=str)
    agent_findings_str = "\n".join(
        f"- {f.agent_name} | {f.status} | {f.finding} | {f.evidence}"
        for f in agent_findings
    )
    risk_summary_str = (
        f"Risk Score: {risk_res['risk_score']}/100 | "
        f"Level: {risk_res['risk_level']} | "
        f"Decision: {risk_res['recommended_decision']}"
    )
    guardrail_summary_str = (
        f"Status: {guardrail_res['status']} | "
        f"Blocked: {', '.join(guardrail_res['blocked_reasons']) or 'None'} | "
        f"Warnings: {', '.join(guardrail_res.get('warning_reasons', [])) or 'None'} | "
        f"Action: {guardrail_res['required_human_action']}"
    )

    # ── 7. Gemini Reasoning Agent ─────────────────────────────────────
    gemini_reasoning = run_gemini_reasoning(
        api_key,
        secure_context_str,
        agent_findings_str,
        risk_summary_str,
        guardrail_summary_str,
    )
    is_fallback = not bool(gemini_reasoning)
    if is_fallback:
        gemini_reasoning = generate_fallback_reasoning(
            case_details,
            [f.model_dump() for f in agent_findings],
            risk_res,
            guardrail_res,
        )

    gemini_agent = _safe_agent(run_gemini_reasoning_agent, case_details, gemini_reasoning, fallback_name=AGENT_GEMINI)
    agent_findings.append(gemini_agent)

    rec_decision = (
        f"System Recommendation: {risk_res['recommended_decision']} | "
        f"Policy Guardrails: {guardrail_res['status']}"
    )
    decision_finding = _safe_agent(run_decision_reasoning_agent, case_details, rec_decision, fallback_name=AGENT_DECISION)
    agent_findings.append(decision_finding)

    # ── 8. Notifications ─────────────────────────────────────────────
    drafts = generate_all_notification_drafts(case_details, risk_res, guardrail_res, gemini_reasoning, decision_workflow)
    notif_finding = _safe_agent(run_notification_agent, case_details, drafts, fallback_name=AGENT_NOTIFICATION)
    agent_findings.append(notif_finding)

    human_finding = _safe_agent(
        run_human_review_agent,
        case_details,
        {"action": "Pending Review", "comments": "Case analysed by AI pipeline. Awaiting Compliance Manager decision."},
        fallback_name=AGENT_HUMAN_REVIEW,
    )
    agent_findings.append(human_finding)

    audit_summary = (
        f"Case analysed. Risk score {risk_res['risk_score']}/100. "
        f"Guardrail status: {guardrail_res['status']}. "
        f"Decision: {decision_workflow.get('final_case_status','Unknown')}."
    )
    audit_finding = _safe_agent(run_audit_agent, case_details, audit_summary, fallback_name=AGENT_AUDIT)
    agent_findings.append(audit_finding)

    # ── 9. Write outputs ─────────────────────────────────────────────
    try:
        trace_path = DIRS["agent_traces"] / f"{case_id}_trace.json"
        with open(trace_path, "w", encoding="utf-8") as f:
            json.dump([af.model_dump() for af in agent_findings], f, indent=2, default=str)
    except Exception as e:
        logger.warning("Trace write failed: %s", e)

    try:
        decision_log = {
            "case_id": case_id,
            "customer_id": cust_id,
            "timestamp": _now(),
            "risk_result": risk_res,
            "guardrail_result": guardrail_res,
            "decision_workflow": decision_workflow,
            "gemini_reasoning_preview": gemini_reasoning[:500] + "..." if len(gemini_reasoning) > 500 else gemini_reasoning,
            "recommendation": rec_decision,
        }
        decision_path = DIRS["decision_logs"] / f"{case_id}_decision.json"
        with open(decision_path, "w", encoding="utf-8") as f:
            json.dump(decision_log, f, indent=2, default=str)
    except Exception as e:
        logger.warning("Decision log write failed: %s", e)

    try:
        audit_trail.append_event(
            event_type="Orchestrator Pipeline Completed",
            actor="TrustShield Master Orchestrator",
            case_id=case_id,
            details=f"Risk score {risk_res['risk_score']}/100. Guardrail: {guardrail_res['status']}. Final status: {decision_workflow.get('final_case_status')}.",
            customer_id=cust_id,
            risk_score=risk_res["risk_score"],
            guardrail_status=guardrail_res["status"],
            final_status=decision_workflow.get("final_case_status"),
            is_fallback=is_fallback,
        )
    except Exception as e:
        logger.warning("Audit trail write failed: %s", e)

    logger.info(
        "Orchestrator: completed %s | score=%s | status=%s | fallback=%s",
        case_id, risk_res["risk_score"], decision_workflow.get("final_case_status"), is_fallback,
    )

    return {
        "success": True,
        "case_id": case_id,
        "customer_id": cust_id,
        "secure_context": secure_context,
        "agent_findings": [af.model_dump() for af in agent_findings],
        "risk_result": risk_res,
        "guardrail_result": guardrail_res,
        "decision_workflow": decision_workflow,
        "gemini_reasoning": gemini_reasoning,
        "recommendation": rec_decision,
        "notification_drafts": drafts,
        "is_fallback": is_fallback,
    }
