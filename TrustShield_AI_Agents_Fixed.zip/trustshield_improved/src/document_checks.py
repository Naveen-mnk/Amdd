import re
from datetime import datetime
import pandas as pd

def check_string_similarity(s1: str, s2: str) -> float:
    """Simple name similarity checker (case-insensitive token overlap)."""
    if not s1 or not s2:
        return 0.0
    w1 = set(re.findall(r'\w+', str(s1).lower()))
    w2 = set(re.findall(r'\w+', str(s2).lower()))
    if not w1 or not w2:
        return 0.0
    intersection = w1.intersection(w2)
    union = w1.union(w2)
    return len(intersection) / len(union)

def run_simulated_ocr_checks(doc: dict, customer: dict, rules: dict) -> dict:
    """
    Simulates OCR verification of extracted document values.
    Returns details on:
    - name_match: Passed / Failed
    - dob_match: Passed / Failed
    - expiry_check: Passed / Failed
    - confidence_check: Passed / Failed
    - tampering_check: Passed / Failed
    - quality_check: Passed / Failed
    - status: Passed / Warning / Failed
    - findings: List of issues found
    """
    findings = []
    status = "Passed"
    
    # 1. Name Mismatch Check
    name_extracted = doc.get("document_name_value", "")
    profile_name = customer.get("full_name", "")
    name_score = check_string_similarity(name_extracted, profile_name)
    
    name_match = "Passed"
    if name_score < 0.65:
        name_match = "Failed"
        status = "Failed"
        findings.append(f"Name mismatch: OCR Extracted '{name_extracted}' vs Profile '{profile_name}'")
    elif name_score < 1.0:
        name_match = "Warning"
        if status != "Failed":
            status = "Warning"
        findings.append(f"Name partial discrepancy: OCR Extracted '{name_extracted}' vs Profile '{profile_name}'")

    # 2. DOB Mismatch Check
    dob_extracted = doc.get("document_dob_value", "")
    profile_dob = customer.get("dob", "")
    
    dob_match = "Passed"
    if dob_extracted != profile_dob:
        dob_match = "Failed"
        status = "Failed"
        findings.append(f"DOB mismatch: OCR Extracted '{dob_extracted}' vs Profile '{profile_dob}'")

    # 3. Address Match Check
    # For KYC, address must be reasonably consistent across all uploaded documents.
    # We use token overlap so small formatting differences do not fail the document.
    address_extracted = doc.get("document_address_value", "")
    profile_address = customer.get("address", "")
    address_match = "Passed"
    if address_extracted and profile_address:
        address_score = check_string_similarity(address_extracted, profile_address)
        if address_score < 0.45:
            address_match = "Failed"
            status = "Failed"
            findings.append(f"Address mismatch: OCR Extracted '{address_extracted}' vs Profile '{profile_address}'")
        elif address_score < 0.75:
            address_match = "Warning"
            if status != "Failed":
                status = "Warning"
            findings.append(f"Address partial discrepancy: OCR Extracted '{address_extracted}' vs Profile '{profile_address}'")

    # 4. Expiry Check
    # Address proof and bank statements have age recency check
    doc_type = doc.get("document_type", "")
    try:
        age_days = int(float(doc.get("document_age_days", 0) or 0))
    except Exception:
        age_days = 0
    
    expiry_check = "Passed"
    if doc_type == "Address Proof":
        max_age = rules.get("address_proof_max_age_days", 90)
        if age_days > max_age:
            expiry_check = "Failed"
            status = "Failed"
            findings.append(f"Address Proof expired: age is {age_days} days (max allowed is {max_age} days)")
    elif doc_type == "Bank Statement":
        max_age = rules.get("bank_statement_max_age_days", 90)
        if age_days > max_age:
            expiry_check = "Failed"
            status = "Failed"
            findings.append(f"Bank Statement expired: age is {age_days} days (max allowed is {max_age} days)")
            
    # General ID expiry check
    expiry_date_str = doc.get("expiry_date", "N/A")
    if expiry_date_str != "N/A" and expiry_date_str and not pd.isna(expiry_date_str):
        try:
            exp_date = datetime.strptime(str(expiry_date_str), "%Y-%m-%d")
            if exp_date < datetime.now():
                expiry_check = "Failed"
                status = "Failed"
                findings.append(f"Document expired: expiration date was {expiry_date_str}")
        except ValueError:
            pass

    # 5. Confidence Score Check
    try:
        confidence = float(doc.get("confidence_score", 1.0) or 1.0)
    except Exception:
        confidence = 1.0
    min_conf = rules.get("min_document_confidence", 0.60)
    confidence_check = "Passed"
    if confidence < min_conf:
        confidence_check = "Failed"
        if status != "Failed":
            status = "Warning"
        findings.append(f"Low confidence OCR extraction score: {confidence:.2f} (threshold is {min_conf:.2f})")

    # 6. Tampering Check
    tampering = doc.get("tampering_indicator", "Not Detected")
    tampering_check = "Passed"
    if tampering == "Detected":
        tampering_check = "Failed"
        status = "Failed"
        findings.append("Tampering detected: image forgery indicators present")

    # 7. Quality Check
    quality = doc.get("quality_status", "Passed")
    quality_check = "Passed"
    if quality in ["Blurred", "Incomplete"]:
        quality_check = "Failed"
        if status != "Failed":
            status = "Warning"
        findings.append(f"Poor image quality check: document is {quality}")

    return {
        "document_type": doc_type,
        "name_match": name_match,
        "dob_match": dob_match,
        "address_match": address_match,
        "expiry_check": expiry_check,
        "confidence_check": confidence_check,
        "tampering_check": tampering_check,
        "quality_check": quality_check,
        "status": status,
        "findings": findings
    }
