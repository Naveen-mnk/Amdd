from pydantic import BaseModel, Field
from datetime import datetime, date
from typing import List, Dict, Any, Optional
from src.constants import *
from src.pii_masking import mask_customer_dict, mask_pan, mask_aadhaar, mask_mobile, mask_bank_account

# ─────────────────────────────────────────────────────────────────
#  Pydantic Schemas
# ─────────────────────────────────────────────────────────────────
class AgentFinding(BaseModel):
    agent_name: str
    status: str  # Passed, Warning, Failed
    finding: str
    evidence: str
    confidence: float
    risk_impact: int
    timestamp: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

class RiskResult(BaseModel):
    risk_score: int
    risk_level: str
    risk_drivers: List[str]
    recommended_decision: str

class GuardrailResult(BaseModel):
    status: str  # Allowed, Warning, Blocked
    blocked_reasons: List[str]
    warning_reasons: List[str] = []
    policy_reference: str
    required_human_action: str

class HumanReviewAction(BaseModel):
    action: str
    comments: str
    override_reason: Optional[str] = None
    reviewer_name: str
    reviewer_role: str
    timestamp: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

class AuditEvent(BaseModel):
    timestamp: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    event_type: str
    actor: str
    case_id: str
    details: str
    ip_address: str = "192.168.1.1"


def _safe_float(val, default=0.0):
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _normalize(s: str) -> str:
    return " ".join(str(s or "").strip().lower().split())


# ─────────────────────────────────────────────────────────────────
#  1. DOCUMENT INTELLIGENCE AGENT
# ─────────────────────────────────────────────────────────────────
def run_document_intelligence_agent(case_details: dict, rules: dict) -> AgentFinding:
    docs = case_details.get("documents", [])
    doc_types = [d.get("document_type") for d in docs]
    mandatory = rules.get("mandatory_documents", ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"])

    missing = [m for m in mandatory if m != "Selfie" and m not in doc_types]

    tampered_docs, expired_docs, blurred_docs, low_conf_docs, invalid_status_docs = [], [], [], [], []

    for doc in docs:
        dtype = doc.get("document_type", "Document")
        tamper = str(doc.get("tampering_indicator", "")).lower()
        if tamper not in ("not detected", "none", "0", "false", "nan", ""):
            tampered_docs.append(dtype)
        if doc.get("document_status") == "Expired":
            expired_docs.append(dtype)
        if doc.get("document_status") in ("Failed", "Rejected", "Invalid"):
            invalid_status_docs.append(dtype)
        if doc.get("quality_status") in ("Blurred", "Incomplete"):
            blurred_docs.append(dtype)
        conf = _safe_float(doc.get("confidence_score", 1.0))
        if conf < rules.get("min_document_confidence", 0.60):
            low_conf_docs.append(f"{dtype} ({conf*100:.0f}%)")

    # Determine status by severity
    if tampered_docs:
        return AgentFinding(
            agent_name=AGENT_DOC_INTEL,
            status="Failed",
            finding=f"Tampering / Forgery Indicators Detected on {len(tampered_docs)} document(s)",
            evidence=f"Affected documents: {', '.join(tampered_docs)}. Tamper-detection model flagged inconsistent metadata, font rendering, or pixel-level artefacts.",
            confidence=0.97,
            risk_impact=30 * len(tampered_docs),
        )
    if missing:
        return AgentFinding(
            agent_name=AGENT_DOC_INTEL,
            status="Failed",
            finding=f"Missing Mandatory Documents: {', '.join(missing)}",
            evidence=f"Onboarding checklist incomplete ({len(docs)}/{len(mandatory)} submitted). Required set: {', '.join(mandatory)}.",
            confidence=0.99,
            risk_impact=len(missing) * 15,
        )
    if invalid_status_docs:
        return AgentFinding(
            agent_name=AGENT_DOC_INTEL,
            status="Failed",
            finding=f"Document Validation Failed: {', '.join(invalid_status_docs)}",
            evidence=f"{len(invalid_status_docs)} document(s) failed automated validation checks and require re-submission.",
            confidence=0.95,
            risk_impact=15 * len(invalid_status_docs),
        )
    if expired_docs:
        return AgentFinding(
            agent_name=AGENT_DOC_INTEL,
            status="Failed",
            finding=f"Expired Document(s): {', '.join(expired_docs)}",
            evidence=f"Document age exceeds the policy threshold of {rules.get('address_proof_max_age_days', 90)} days for proof-of-address class documents.",
            confidence=0.99,
            risk_impact=20 * len(expired_docs),
        )
    if low_conf_docs:
        return AgentFinding(
            agent_name=AGENT_DOC_INTEL,
            status="Warning",
            finding=f"Low OCR Confidence on {len(low_conf_docs)} document(s)",
            evidence=f"Confidence below threshold: {', '.join(low_conf_docs)}. Manual visual verification recommended.",
            confidence=0.85,
            risk_impact=10 * len(low_conf_docs),
        )
    if blurred_docs:
        return AgentFinding(
            agent_name=AGENT_DOC_INTEL,
            status="Warning",
            finding=f"Low Resolution / Incomplete Image(s): {', '.join(blurred_docs)}",
            evidence="Image quality reduces OCR reliability. Recommend requesting a re-upload in good lighting.",
            confidence=0.88,
            risk_impact=10 * len(blurred_docs),
        )

    return AgentFinding(
        agent_name=AGENT_DOC_INTEL,
        status="Passed",
        finding="All mandatory documents present and verified",
        evidence=f"Successfully validated {len(docs)} documents against {len(mandatory)} mandatory categories. No tampering, expiry, or quality issues found.",
        confidence=0.96,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  1B. CROSS-DOCUMENT CONSISTENCY AGENT
#      Compares name / DOB / address across ALL uploaded documents
#      pairwise — not just each document vs. the registration profile.
#      Catches the case where two documents agree with the profile
#      individually (within fuzzy tolerance) but disagree with EACH OTHER,
#      a classic synthetic-identity / document-stitching fraud pattern.
# ─────────────────────────────────────────────────────────────────
def run_cross_document_consistency_agent(case_details: dict, rules: dict) -> AgentFinding:
    docs = [d for d in case_details.get("documents", []) if str(d.get("document_status", "")).lower() != "missing"]

    if len(docs) < 2:
        return AgentFinding(
            agent_name=AGENT_CROSS_DOC,
            status="Warning",
            finding="Insufficient Documents for Cross-Document Comparison",
            evidence=f"Only {len(docs)} document(s) available. At least 2 documents are required to cross-verify identity fields against each other.",
            confidence=0.80,
            risk_impact=5,
        )

    name_mismatches, dob_mismatches, addr_mismatches = [], [], []

    for i in range(len(docs)):
        for j in range(i + 1, len(docs)):
            d1, d2 = docs[i], docs[j]
            t1, t2 = d1.get("document_type", "Doc A"), d2.get("document_type", "Doc B")

            n1, n2 = _normalize(d1.get("document_name_value", "")), _normalize(d2.get("document_name_value", ""))
            if n1 and n2 and n1 != n2:
                tok1, tok2 = set(n1.split()), set(n2.split())
                if not tok1.intersection(tok2):
                    name_mismatches.append(f"{t1} ('{d1.get('document_name_value')}') vs {t2} ('{d2.get('document_name_value')}')")

            dob1 = str(d1.get("document_dob_value", "")).strip()
            dob2 = str(d2.get("document_dob_value", "")).strip()
            if dob1 and dob2 and dob1 != dob2:
                dob_mismatches.append(f"{t1} ('{dob1}') vs {t2} ('{dob2}')")

            a1 = _normalize(d1.get("document_address_value", ""))
            a2 = _normalize(d2.get("document_address_value", ""))
            if a1 and a2 and a1 != a2:
                tok1, tok2 = set(a1.split()), set(a2.split())
                overlap = len(tok1 & tok2) / max(1, len(tok1 | tok2))
                if overlap < 0.45:
                    addr_mismatches.append(f"{t1} vs {t2}")

    if name_mismatches:
        return AgentFinding(
            agent_name=AGENT_CROSS_DOC,
            status="Failed",
            finding=f"Identity Name Conflict Across Submitted Documents ({len(name_mismatches)} pair(s))",
            evidence="Documents disagree with each other on the customer's name, independent of the registration profile: " + "; ".join(name_mismatches[:3]) + (" ..." if len(name_mismatches) > 3 else "") + ". This pattern is consistent with document substitution or a synthetic identity assembled from multiple real identities.",
            confidence=0.93,
            risk_impact=25,
        )
    if dob_mismatches:
        return AgentFinding(
            agent_name=AGENT_CROSS_DOC,
            status="Failed",
            finding=f"Date-of-Birth Conflict Across Submitted Documents ({len(dob_mismatches)} pair(s))",
            evidence="Documents disagree with each other on date of birth: " + "; ".join(dob_mismatches[:3]) + (" ..." if len(dob_mismatches) > 3 else "") + ". Internally inconsistent identity documents are a strong fraud indicator regardless of profile match.",
            confidence=0.92,
            risk_impact=20,
        )
    if addr_mismatches:
        return AgentFinding(
            agent_name=AGENT_CROSS_DOC,
            status="Warning",
            finding=f"Address Inconsistency Across Submitted Documents ({len(addr_mismatches)} pair(s))",
            evidence="Documents show materially different addresses from each other: " + "; ".join(addr_mismatches[:3]) + ". May indicate a recent house move (low concern) or mixed identity records (high concern) — recommend manual confirmation.",
            confidence=0.78,
            risk_impact=8,
        )

    return AgentFinding(
        agent_name=AGENT_CROSS_DOC,
        status="Passed",
        finding=f"All {len(docs)} Documents Internally Consistent",
        evidence=f"Name, date of birth, and address extracted from all {len(docs)} submitted documents agree with each other, in addition to matching the registration profile. No document-stitching or substitution patterns detected.",
        confidence=0.95,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  2. IDENTITY VERIFICATION AGENT
# ─────────────────────────────────────────────────────────────────
def run_identity_verification_agent(case_details: dict, rules: dict) -> AgentFinding:
    selfie = case_details.get("selfie_verification", {})
    cust = case_details.get("customer", {})
    docs = case_details.get("documents", [])

    if not selfie or not selfie.get("selfie_available", 0):
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding="Selfie Photo Missing",
            evidence="Onboarding selfie image was not uploaded. Liveness and facial-match checks cannot be performed.",
            confidence=1.0,
            risk_impact=15,
        )

    match_score = _safe_float(selfie.get("selfie_match_score", 1.0))
    liveness = selfie.get("liveness_check", "Passed")
    quality = selfie.get("selfie_quality", "Passed")

    # Demographic cross-checks
    name_mismatches, dob_mismatches, partial_name_mismatches = [], [], []
    prof_name_n = _normalize(cust.get("full_name", ""))
    prof_dob = str(cust.get("dob", "")).strip()

    for doc in docs:
        dtype = doc.get("document_type")
        doc_name_n = _normalize(doc.get("document_name_value", ""))
        doc_dob = str(doc.get("document_dob_value", "")).strip()

        if doc_name_n and prof_name_n:
            d_tok, p_tok = set(doc_name_n.split()), set(prof_name_n.split())
            if not d_tok.intersection(p_tok):
                name_mismatches.append(f"{dtype}: '{doc.get('document_name_value')}' vs profile '{cust.get('full_name')}'")
            elif d_tok != p_tok:
                partial_name_mismatches.append(f"{dtype}: minor spelling/order difference")

        if doc_dob and prof_dob and doc_dob != prof_dob:
            dob_mismatches.append(f"{dtype}: '{doc_dob}' vs profile '{prof_dob}'")

    if liveness == "Failed":
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding="Identity Spoofing / Liveness Check Failed",
            evidence="The selfie did not pass live-capture face verification. Possible use of a photo, screen, or printed image instead of a live capture.",
            confidence=0.98,
            risk_impact=25,
        )
    if match_score < 0.50:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding=f"Facial Match Failed: Similarity {match_score*100:.0f}%",
            evidence="The facial comparison between the onboarding selfie and the Aadhaar/PAN photo failed to meet the minimum matching threshold of 50%.",
            confidence=0.94,
            risk_impact=25,
        )
    if name_mismatches:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding="Identity Name Mismatch — No Token Overlap",
            evidence="; ".join(name_mismatches),
            confidence=0.93,
            risk_impact=15 * len(name_mismatches),
        )
    if dob_mismatches:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding="Date-of-Birth Mismatch Between Document and Profile",
            evidence="; ".join(dob_mismatches),
            confidence=0.95,
            risk_impact=15 * len(dob_mismatches),
        )
    if match_score < 0.75:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Warning",
            finding=f"Facial Match Borderline: Similarity {match_score*100:.0f}%",
            evidence="Match score is between 50–75%. Recommend manual visual comparison by a reviewer before approval.",
            confidence=0.85,
            risk_impact=10,
        )
    if quality == "Poor":
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Warning",
            finding="Poor Selfie Image Quality",
            evidence=f"Selfie quality flagged as '{quality}'. Match score {match_score*100:.0f}% may be less reliable.",
            confidence=0.80,
            risk_impact=10,
        )
    if partial_name_mismatches:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Warning",
            finding="Minor Name Spelling/Order Discrepancy",
            evidence="; ".join(partial_name_mismatches),
            confidence=0.88,
            risk_impact=5,
        )

    return AgentFinding(
        agent_name=AGENT_IDENTITY_VER,
        status="Passed",
        finding="Facial Verification and Demographics Aligned",
        evidence=f"Match score: {match_score*100:.0f}%. Liveness: Passed. Name and DOB consistent across all submitted documents.",
        confidence=0.97,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  3. COMPLIANCE RAG AGENT
# ─────────────────────────────────────────────────────────────────
def run_compliance_rag_agent(case_details: dict, rules: dict) -> AgentFinding:
    cust = case_details.get("customer", {})
    dob = cust.get("dob", "")
    min_age = rules.get("minimum_age", 18)

    try:
        birth = datetime.strptime(str(dob)[:10], "%Y-%m-%d")
        age = (datetime.now() - birth).days // 365
    except Exception:
        age = min_age

    if age < min_age:
        return AgentFinding(
            agent_name=AGENT_COMPLIANCE_RAG,
            status="Failed",
            finding="Minimum Age Policy Violation",
            evidence=f"Customer is {age} years old. RBI KYC Master Direction requires a minimum age of {min_age} for individual account opening (guardian-operated accounts excluded).",
            confidence=1.0,
            risk_impact=30,
        )
    if age > 80:
        senior_finding = AgentFinding(
            agent_name=AGENT_COMPLIANCE_RAG,
            status="Warning",
            finding="Senior Citizen Profile — Enhanced Care Protocol Recommended",
            evidence=f"Customer is {age} years old. Recommend assisted-onboarding protocol and additional verbal confirmation of consent per fair-practice guidelines.",
            confidence=0.90,
            risk_impact=5,
        )
    else:
        senior_finding = None

    expired_addr = any(
        d.get("document_type") == "Address Proof" and d.get("document_status") == "Expired"
        for d in case_details.get("documents", [])
    )
    if expired_addr:
        return AgentFinding(
            agent_name=AGENT_COMPLIANCE_RAG,
            status="Failed",
            finding="Address Proof Recency Policy Violation",
            evidence=f"Proof of address is older than the policy threshold of {rules.get('address_proof_max_age_days', 90)} days, per RBI guidelines on document recency for CDD.",
            confidence=0.99,
            risk_impact=20,
        )

    if senior_finding:
        return senior_finding

    return AgentFinding(
        agent_name=AGENT_COMPLIANCE_RAG,
        status="Passed",
        finding="Basic Policy Criteria Aligned",
        evidence=f"Customer meets minimum-age ({age} ≥ {min_age}) and document-recency requirements under the current KYC policy ruleset.",
        confidence=0.96,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  4. AML & SANCTIONS AGENT
# ─────────────────────────────────────────────────────────────────
def run_aml_sanctions_agent(case_details: dict, rules: dict) -> AgentFinding:
    sanctions = case_details.get("sanctions_watchlist", {})
    match = sanctions.get("sanctions_match", 0)
    high_risk_country = sanctions.get("high_risk_country", 0)
    remarks = sanctions.get("remarks", "Clear")

    if match:
        return AgentFinding(
            agent_name=AGENT_AML_SANCTIONS,
            status="Failed",
            finding="Sanctions / AML Watchlist Match Detected",
            evidence=f"{remarks}. This is a hard-block under RBI/PMLA guidelines — onboarding cannot proceed without senior compliance override and STR filing review.",
            confidence=0.99,
            risk_impact=45,
        )
    if high_risk_country:
        return AgentFinding(
            agent_name=AGENT_AML_SANCTIONS,
            status="Warning",
            finding="High-Risk Geography Connection Identified",
            evidence=f"{remarks}. Customer's nationality or address links to an FATF-flagged or high-risk jurisdiction — Enhanced Due Diligence (EDD) required.",
            confidence=0.91,
            risk_impact=20,
        )
    return AgentFinding(
        agent_name=AGENT_AML_SANCTIONS,
        status="Passed",
        finding="Clear of Sanctions / AML Watchlists",
        evidence="No records matching name, DOB, or nationality found on UN, OFAC, or Indian MHA sanctions registries.",
        confidence=0.95,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  5. PEP SCREENING AGENT
# ─────────────────────────────────────────────────────────────────
def run_pep_screening_agent(case_details: dict, rules: dict) -> AgentFinding:
    pep = case_details.get("pep_watchlist", {})
    match = pep.get("pep_match", 0)
    category = pep.get("pep_category", "None")
    remarks = pep.get("remarks", "Clear")

    if match:
        cat_lower = str(category).lower()
        impact = 25 if "1" in cat_lower or "category-1" in cat_lower else 18
        return AgentFinding(
            agent_name=AGENT_PEP_SCREENING,
            status="Warning",
            finding=f"Politically Exposed Person (PEP) Match: {category}",
            evidence=f"{remarks}. Per FATF Recommendation 12, Enhanced Due Diligence including senior management approval and ongoing monitoring is mandatory.",
            confidence=0.97,
            risk_impact=impact,
        )
    return AgentFinding(
        agent_name=AGENT_PEP_SCREENING,
        status="Passed",
        finding="No PEP Status Matches",
        evidence="Customer is not listed as a domestic or foreign politically exposed person, or a close associate/family member of one.",
        confidence=0.95,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  6. ADVERSE MEDIA AGENT
# ─────────────────────────────────────────────────────────────────
def run_adverse_media_agent(case_details: dict, rules: dict) -> AgentFinding:
    adverse = case_details.get("adverse_media", {})
    match = adverse.get("adverse_media_match", 0)
    remarks = adverse.get("remarks", "Clear")

    if match:
        severity = str(adverse.get("severity", "")).lower()
        impact = 25 if "high" in severity or "critical" in severity else 20
        return AgentFinding(
            agent_name=AGENT_ADVERSE_MEDIA,
            status="Warning",
            finding="Negative Media Scrutiny Hit",
            evidence=f"{remarks}. Compliance officer should assess relevance and recency of the reported matter before final decisioning.",
            confidence=0.87,
            risk_impact=impact,
        )
    return AgentFinding(
        agent_name=AGENT_ADVERSE_MEDIA,
        status="Passed",
        finding="No Negative Media Scrutiny",
        evidence="No adverse news, regulatory action, or litigation reports found matching the customer's identity across monitored media sources.",
        confidence=0.92,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  7. FINANCIAL PROFILING AGENT
# ─────────────────────────────────────────────────────────────────
def run_financial_profiling_agent(case_details: dict, rules: dict) -> AgentFinding:
    cust = case_details.get("customer", {})
    income = cust.get("income_range", "< 5 LPA")
    occupation = cust.get("occupation", "Unemployed")
    txns = case_details.get("transactions", [])

    total_txn = sum(_safe_float(t.get("amount", 0)) for t in txns)
    income_ceiling_map = {
        "Below 5L": 500_000, "<5L": 500_000, "5L-10L": 1_000_000,
        "10L-25L": 2_500_000, "25L-50L": 5_000_000, "25L+": 5_000_000, "50L+": 10_000_000,
    }
    ceiling = income_ceiling_map.get(income, 0)

    # High-risk occupation/income mismatch
    if occupation in ("Retired", "Student", "Unemployed") and income in ("25L-50L", "50L+", "25L+"):
        return AgentFinding(
            agent_name=AGENT_FINANCIAL_PROFILE,
            status="Warning",
            finding="Income–Occupation Profile Mismatch",
            evidence=f"Declared income band '{income}' is unusually high for occupation '{occupation}'. Source-of-funds clarification recommended.",
            confidence=0.84,
            risk_impact=10,
        )

    # Transaction volume vs declared income
    if ceiling and total_txn > ceiling * 2:
        return AgentFinding(
            agent_name=AGENT_FINANCIAL_PROFILE,
            status="Warning",
            finding="Transaction Volume Exceeds Declared Income Ceiling",
            evidence=f"Observed transaction volume (₹{total_txn:,.0f}) is more than 2× the declared income band ceiling (₹{ceiling:,.0f} for '{income}'). Possible undeclared income source.",
            confidence=0.82,
            risk_impact=8,
        )

    return AgentFinding(
        agent_name=AGENT_FINANCIAL_PROFILE,
        status="Passed",
        finding="Financial Profile Consistent with Occupation",
        evidence=f"Occupation: {occupation} | Income Band: {income} | Observed transaction volume (₹{total_txn:,.0f}) is within expected range.",
        confidence=0.88,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  8. FRAUD INTELLIGENCE AGENT
# ─────────────────────────────────────────────────────────────────
def run_fraud_intelligence_agent(case_details: dict, rules: dict) -> AgentFinding:
    fraud = case_details.get("fraud_watchlist", {})
    if not fraud:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Passed",
            finding="Clear of Fraud Watchlists",
            evidence="No matching duplicate mobile, PAN, bank account, or synthetic identity patterns found in the fraud intelligence database.",
            confidence=0.95,
            risk_impact=0,
        )

    dup_pan = fraud.get("duplicate_pan", 0)
    dup_mob = fraud.get("duplicate_mobile", 0)
    dup_bank = fraud.get("duplicate_bank_account", 0)
    synth = fraud.get("synthetic_identity_signal", 0)
    repeated = fraud.get("repeated_kyc_attempt", 0)
    pattern = fraud.get("fraud_pattern", "None")

    triggered = []
    if dup_pan:
        triggered.append("Duplicate PAN")
    if synth:
        triggered.append("Synthetic Identity Signal")
    if dup_mob:
        triggered.append("Duplicate Mobile")
    if dup_bank:
        triggered.append("Duplicate Bank Account")
    if repeated:
        triggered.append("Repeated KYC Attempts")

    if dup_pan and synth:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Failed",
            finding="Multiple Critical Fraud Signals: Duplicate PAN + Synthetic Identity",
            evidence=f"Both a duplicate PAN match and synthetic-identity demographic pattern were detected. Signature: {pattern}. Recommend immediate fraud-team escalation and STR review.",
            confidence=0.98,
            risk_impact=55,
        )
    if dup_pan:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Failed",
            finding="Duplicate PAN Flag",
            evidence=f"This PAN is already registered on another active customer profile. Signature: {pattern}. Possible identity duplication or fraud ring activity.",
            confidence=0.99,
            risk_impact=30,
        )
    if synth:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Failed",
            finding="Synthetic Identity Risk Detected",
            evidence=f"Demographics align with known shell/synthetic-identity markers (e.g. mismatched issue dates, sequential IDs). Signature: {pattern}.",
            confidence=0.92,
            risk_impact=25,
        )
    if dup_mob and dup_bank:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Failed",
            finding="Multiple Shared-Identifier Flags: Mobile + Bank Account",
            evidence=f"Both mobile number and bank account are shared with other customer records. Signature: {pattern}. Possible mule-account network.",
            confidence=0.90,
            risk_impact=30,
        )
    if dup_mob or dup_bank:
        which = "mobile number" if dup_mob else "bank account"
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Warning",
            finding=f"Shared {which.title()} Detected",
            evidence=f"The {which} matches another customer record in the shared-identifier registry. Signature: {pattern}.",
            confidence=0.87,
            risk_impact=15,
        )
    if repeated:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Warning",
            finding="Repeated KYC Registration Attempts",
            evidence=f"This identity has attempted KYC registration multiple times. Signature: {pattern}. May indicate prior rejection or evasion attempts.",
            confidence=0.85,
            risk_impact=10,
        )

    return AgentFinding(
        agent_name=AGENT_FRAUD_INTEL,
        status="Passed",
        finding="Clear of Fraud Watchlists",
        evidence="No matching duplicate mobile, PAN, bank account, or synthetic identity patterns found.",
        confidence=0.95,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  9. TRANSACTION RISK AGENT
# ─────────────────────────────────────────────────────────────────
def run_transaction_risk_agent(case_details: dict, rules: dict) -> AgentFinding:
    txns = case_details.get("transactions", [])
    suspicious = sum(1 for t in txns if t.get("suspicious_txn_flag", 0))
    high_val = sum(1 for t in txns if t.get("high_value_flag", 0))
    velocity = sum(1 for t in txns if t.get("velocity_risk", 0))
    total_amount = sum(_safe_float(t.get("amount", 0)) for t in txns)

    if suspicious > 0 and velocity > 2:
        return AgentFinding(
            agent_name=AGENT_TX_RISK,
            status="Failed",
            finding="Suspicious Transaction Pattern with High Velocity",
            evidence=f"Detected {suspicious} suspicious transaction(s) and {velocity} velocity-risk events across {len(txns)} total transactions (₹{total_amount:,.0f}). Pattern consistent with structuring/layering.",
            confidence=0.93,
            risk_impact=25,
        )
    if suspicious > 0:
        return AgentFinding(
            agent_name=AGENT_TX_RISK,
            status="Failed",
            finding="Suspicious Transaction Pattern Flagged",
            evidence=f"Detected {suspicious} of {len(txns)} transactions flagged for suspicious structural or velocity markers (total volume ₹{total_amount:,.0f}).",
            confidence=0.91,
            risk_impact=15,
        )
    if velocity > 2:
        return AgentFinding(
            agent_name=AGENT_TX_RISK,
            status="Warning",
            finding="Elevated Transaction Velocity",
            evidence=f"{velocity} transactions exceeded normal frequency thresholds within the monitored window — total volume ₹{total_amount:,.0f}.",
            confidence=0.86,
            risk_impact=10,
        )
    if high_val > 0:
        return AgentFinding(
            agent_name=AGENT_TX_RISK,
            status="Warning",
            finding="High-Value Transactions Detected",
            evidence=f"Detected {high_val} high-value transaction(s) out of {len(txns)} total (₹{total_amount:,.0f} aggregate). Within policy but flagged for visibility.",
            confidence=0.88,
            risk_impact=10,
        )
    return AgentFinding(
        agent_name=AGENT_TX_RISK,
        status="Passed",
        finding="Transaction Velocity and Amounts Within Normal Range",
        evidence=f"Analyzed {len(txns)} transactions (₹{total_amount:,.0f} total). All values are within standard retail thresholds; no velocity or structuring alerts.",
        confidence=0.94,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  10. RISK INTELLIGENCE AGENT
# ─────────────────────────────────────────────────────────────────
def run_risk_intelligence_agent(case_details: dict, risk_result: dict) -> AgentFinding:
    score = risk_result.get("risk_score", 0)
    level = risk_result.get("risk_level", "Low")
    drivers = risk_result.get("risk_drivers", [])
    top_drivers = "; ".join(drivers[:3]) if drivers else "None"

    status = "Passed" if level == "Low" else "Warning" if level == "Medium" else "Failed"

    return AgentFinding(
        agent_name=AGENT_RISK_INTEL,
        status=status,
        finding=f"Composite Risk Score: {score}/100 — {level} Risk Tier ({len(drivers)} driver(s))",
        evidence=f"Top contributing factors: {top_drivers}",
        confidence=0.98,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  11. GUARDRAIL AGENT
# ─────────────────────────────────────────────────────────────────
def run_guardrail_agent(case_details: dict, guardrail_result: dict) -> AgentFinding:
    status = guardrail_result.get("status", "Allowed")
    blocked = guardrail_result.get("blocked_reasons", [])
    warnings_list = guardrail_result.get("warning_reasons", [])
    action = guardrail_result.get("required_human_action", "")
    policy_ref = guardrail_result.get("policy_reference", "")

    if status == "Blocked":
        return AgentFinding(
            agent_name=AGENT_GUARDRAIL,
            status="Failed",
            finding=f"Compliance Guardrail BLOCKED — {len(blocked)} hard-stop trigger(s)",
            evidence=f"Triggers: {', '.join(blocked)}. Required action: {action}. Policy: {policy_ref}",
            confidence=1.0,
            risk_impact=0,
        )
    if status == "Warning":
        return AgentFinding(
            agent_name=AGENT_GUARDRAIL,
            status="Warning",
            finding=f"Compliance Guardrail WARNING — {len(warnings_list)} EDD trigger(s)",
            evidence=f"Triggers: {', '.join(warnings_list)}. Required action: {action}. Policy: {policy_ref}",
            confidence=1.0,
            risk_impact=0,
        )
    return AgentFinding(
        agent_name=AGENT_GUARDRAIL,
        status="Passed",
        finding="Compliance Guardrail Checks Passed",
        evidence=f"No hard blocks or EDD triggers found. {action}. Policy: {policy_ref}",
        confidence=1.0,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  12. GEMINI REASONING AGENT
# ─────────────────────────────────────────────────────────────────
def run_gemini_reasoning_agent(case_details: dict, gemini_output: str) -> AgentFinding:
    is_fallback = "Rule-Based Compliance Engine" in gemini_output or "FALLBACK" in gemini_output
    word_count = len(gemini_output.split())

    return AgentFinding(
        agent_name=AGENT_GEMINI,
        status="Passed",
        finding="Natural Language Compliance Reasoning Compiled",
        evidence=f"Output Mode: {'Deterministic Rule-Based Fallback' if is_fallback else 'Gemini AI Model Reasoning'} | Report length: ~{word_count} words.",
        confidence=0.90 if not is_fallback else 0.85,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  13. DECISION REASONING AGENT
# ─────────────────────────────────────────────────────────────────
def run_decision_reasoning_agent(case_details: dict, decision_desc: str) -> AgentFinding:
    return AgentFinding(
        agent_name=AGENT_DECISION,
        status="Passed",
        finding="Final Compliance Recommendation Finalized",
        evidence=decision_desc,
        confidence=0.95,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  14. NOTIFICATION AGENT
# ─────────────────────────────────────────────────────────────────
def run_notification_agent(case_details: dict, drafts: dict) -> AgentFinding:
    draft_names = ", ".join(drafts.keys())
    return AgentFinding(
        agent_name=AGENT_NOTIFICATION,
        status="Passed",
        finding=f"Communication Drafts Compiled ({len(drafts)})",
        evidence=f"Generated drafts: {draft_names}.",
        confidence=0.92,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  15. HUMAN REVIEW AGENT
# ─────────────────────────────────────────────────────────────────
def run_human_review_agent(case_details: dict, human_action: dict) -> AgentFinding:
    action = human_action.get("action", "None")
    reviewer = human_action.get("reviewer_name", "System")
    role = human_action.get("reviewer_role", "Orchestrator")
    comments = human_action.get("comments", "Pending Review")

    return AgentFinding(
        agent_name=AGENT_HUMAN_REVIEW,
        status="Passed" if action != "Reject" else "Failed",
        finding=f"Review Action: {action} by {reviewer} ({role})",
        evidence=f"Reviewer comments: '{comments}'",
        confidence=1.0,
        risk_impact=0,
    )


# ─────────────────────────────────────────────────────────────────
#  16. AUDIT AGENT
# ─────────────────────────────────────────────────────────────────
def run_audit_agent(case_details: dict, audit_trail_summary: str) -> AgentFinding:
    return AgentFinding(
        agent_name=AGENT_AUDIT,
        status="Passed",
        finding="Tamper-Evident Audit Event Appended",
        evidence=audit_trail_summary,
        confidence=1.0,
        risk_impact=0,
    )
