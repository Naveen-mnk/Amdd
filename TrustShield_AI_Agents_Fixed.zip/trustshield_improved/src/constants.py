# KYC Case Statuses
STATUS_NEW = "New"
STATUS_DOC_PENDING = "Document Pending"
STATUS_DOC_UPLOADED = "Document Uploaded"
STATUS_VALIDATION_IN_PROGRESS = "Validation In Progress"
STATUS_AGENT_REVIEW_IN_PROGRESS = "Agent Review In Progress"
STATUS_MANUAL_REVIEW_REQUIRED = "Manual Review Required"
STATUS_ESCALATED_COMPLIANCE = "Escalated to Compliance"
STATUS_ESCALATED_FRAUD = "Escalated to Fraud Team"
STATUS_MORE_DOCS_REQUIRED = "More Documents Required"
STATUS_SENIOR_APPROVAL_REQUIRED = "Senior Approval Required"
STATUS_APPROVED = "Approved"
STATUS_REJECTED = "Rejected"
STATUS_CLOSED = "Closed"

ALL_STATUSES = [
    STATUS_NEW,
    STATUS_DOC_PENDING,
    STATUS_DOC_UPLOADED,
    STATUS_VALIDATION_IN_PROGRESS,
    STATUS_AGENT_REVIEW_IN_PROGRESS,
    STATUS_MANUAL_REVIEW_REQUIRED,
    STATUS_ESCALATED_COMPLIANCE,
    STATUS_ESCALATED_FRAUD,
    STATUS_MORE_DOCS_REQUIRED,
    STATUS_SENIOR_APPROVAL_REQUIRED,
    STATUS_APPROVED,
    STATUS_REJECTED,
    STATUS_CLOSED
]

# Risk Classifications
RISK_LOW = "Low"
RISK_MEDIUM = "Medium"
RISK_HIGH = "High"
RISK_CRITICAL = "Critical"

# Risk Scores
RISK_LIMIT_LOW = 30
RISK_LIMIT_MEDIUM = 60
RISK_LIMIT_HIGH = 80

# Agent Names
AGENT_ORCHESTRATOR = "Master Orchestrator Agent"
AGENT_DOC_INTEL = "Document Intelligence Agent"
AGENT_CROSS_DOC = "Cross-Document Consistency Agent"
AGENT_IDENTITY_VER = "Identity Verification Agent"
AGENT_COMPLIANCE_RAG = "Compliance RAG Agent"
AGENT_AML_SANCTIONS = "AML & Sanctions Screening Agent"
AGENT_PEP_SCREENING = "PEP Screening Agent"
AGENT_ADVERSE_MEDIA = "Adverse Media Intelligence Agent"
AGENT_FINANCIAL_PROFILE = "Financial Profiling Agent"
AGENT_FRAUD_INTEL = "Fraud Intelligence Agent"
AGENT_TX_RISK = "Transaction Risk Agent"
AGENT_RISK_INTEL = "Risk Intelligence Agent"
AGENT_GUARDRAIL = "Guardrail & Policy Validation Agent"
AGENT_GEMINI = "Gemini Reasoning Agent"
AGENT_DECISION = "Decision Reasoning Agent"
AGENT_NOTIFICATION = "Notification & Email Agent"
AGENT_HUMAN_REVIEW = "Human Review Agent"
AGENT_AUDIT = "Audit & Governance Agent"
