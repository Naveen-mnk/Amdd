# TrustShield AI Agents

Separate AI agent layer for AGENTS_002 - Agentic KYC Intelligence Platform.

## Agents
- Orchestrator Agent
- Document Intelligence Agent
- Identity Verification Agent
- Selective PII Masking Agent
- Compliance RAG Agent
- AML & Sanctions Screening Agent
- Adverse Media Intelligence Agent
- Financial Profiling Agent
- Fraud Intelligence Agent
- Risk Intelligence Agent
- Decision Reasoning Agent
- Human Review Agent
- Notification & Email Agent
- Audit & Governance Agent

The FastAPI app triggers these agents from the Customer 360 profile and agent run APIs.
