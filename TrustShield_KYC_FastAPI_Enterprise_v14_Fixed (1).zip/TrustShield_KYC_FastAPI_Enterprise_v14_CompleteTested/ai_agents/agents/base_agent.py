
from datetime import datetime

class BaseKYCAgent:
    agent_id = "base"
    name = "Base KYC Agent"
    stage = "Base"
    purpose = "Base class for TrustShield KYC agents."
    icon = "🤖"

    def __init__(self, context=None):
        self.context = context or {}

    def _issue_count(self):
        return len(self.context.get("issues", []) or [])

    def _cust(self):
        return self.context.get("cust", {}) or {}

    def _decision(self):
        return self.context.get("decision", "Manual Review Required")

    def run(self):
        return {
            "agent_id": self.agent_id,
            "agent_name": self.name,
            "stage": self.stage,
            "purpose": self.purpose,
            "status": "Completed",
            "confidence": 90,
            "finding": "Agent check completed.",
            "evidence": [],
            "output": "Completed",
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        }
