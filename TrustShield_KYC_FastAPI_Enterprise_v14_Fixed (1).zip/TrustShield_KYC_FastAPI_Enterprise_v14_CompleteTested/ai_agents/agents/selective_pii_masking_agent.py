
from .base_agent import BaseKYCAgent

class SelectivePIIMaskingAgent(BaseKYCAgent):
    agent_id = "selective_pii_masking"
    name = "Selective PII Masking Agent"
    stage = "Privacy Protection"
    purpose = "Masks sensitive fields before display, logs, notifications and evidence pack sharing."
    icon = "🔐"

    def run(self):
        issue_count = self._issue_count()
        cust = self._cust()
        decision = self._decision()
        confidence = max(60, 96 - issue_count * 6)
        evidence = [
            f"Case ID: {cust.get('case_id', 'N/A')}",
            f"Customer ID: {cust.get('customer_id', 'N/A')}",
            f"Issue count: {issue_count}",
            f"Current decision: {decision}",
        ]
        return {
            "agent_id": self.agent_id,
            "agent_name": self.name,
            "stage": self.stage,
            "purpose": self.purpose,
            "status": "Completed" if self.agent_id != "human_review" or decision != "Approved" else "Not Required",
            "confidence": int(confidence),
            "finding": "PII masking policy applied to sensitive fields.",
            "evidence": evidence,
            "output": self.purpose,
        }
