# Document Intelligence Agent

Role: Extracts and validates fields from PAN, Aadhaar, passport, salary slip, bank statement and address proof.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.
