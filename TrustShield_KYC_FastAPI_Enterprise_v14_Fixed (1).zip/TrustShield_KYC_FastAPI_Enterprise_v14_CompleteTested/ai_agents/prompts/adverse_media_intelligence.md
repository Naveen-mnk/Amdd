# Adverse Media Intelligence Agent

Role: Checks adverse media and reputation risk indicators.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.
