# Decision Reasoning Agent

Role: Applies KYC decision rules and generates final recommendation with evidence.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.
