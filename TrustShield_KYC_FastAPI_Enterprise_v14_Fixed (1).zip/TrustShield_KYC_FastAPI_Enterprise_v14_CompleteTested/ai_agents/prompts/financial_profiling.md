# Financial Profiling Agent

Role: Validates occupation, declared income, transactions and bank statement consistency.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.
