# Selective PII Masking Agent

Role: Masks sensitive fields before display, logs, notifications and evidence pack sharing.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.
