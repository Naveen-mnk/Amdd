# Fraud Intelligence Agent

Role: Detects tampering, duplicate identity, suspicious channel and document-photo mismatch risk.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.
