# Human Review Agent

Role: Routes exception cases to staff, manager approval or remediation queue.

Inputs: customer profile, document evidence, screening data, transaction profile, discrepancy list.

Output: status, confidence, finding, evidence, and recommendation.
