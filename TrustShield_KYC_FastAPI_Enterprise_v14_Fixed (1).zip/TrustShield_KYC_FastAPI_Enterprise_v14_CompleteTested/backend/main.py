
import os, json, shutil, re, time
from pathlib import Path
from datetime import datetime
from typing import Optional
import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Form, UploadFile, File, Depends
from fastapi.responses import RedirectResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE/'.env')
APP_SECRET = os.getenv('APP_SECRET_KEY') or os.getenv('SESSION_SECRET') or 'trustshield-secret'
MODEL = os.getenv('GEMINI_MODEL','gemini-3.5-flash')
API_KEY = os.getenv('GOOGLE_API_KEY','')

app = FastAPI(title='TrustShield KYC Enterprise Platform', version='14.0')
app.add_middleware(SessionMiddleware, secret_key=APP_SECRET)
app.mount('/static', StaticFiles(directory=BASE/'frontend'/'static'), name='static')
app.mount('/uploads', StaticFiles(directory=BASE/'uploads'), name='uploads')
templates = Jinja2Templates(directory=str(BASE/'frontend'/'templates'))

for _d in ['outputs/agent_traces','outputs/audit_logs','uploads/customer_uploaded_documents','uploads/staff_uploaded_documents']:
    (BASE/_d).mkdir(parents=True, exist_ok=True)


def read_csv(name):
    p = BASE/'data'/name
    return pd.read_csv(p) if p.exists() else pd.DataFrame()

def load_data():
    return {
        'customers': read_csv('customers.csv'),
        'docs': read_csv('kyc_documents.csv'),
        'files': read_csv('document_file_registry.csv'),
        'history': read_csv('case_history.csv'),
        'selfie': read_csv('selfie_verification.csv'),
        'txns': read_csv('transactions.csv'),
        'sanctions': read_csv('sanctions_watchlist.csv'),
        'pep': read_csv('pep_watchlist.csv'),
        'fraud': read_csv('fraud_watchlist.csv'),
        'adverse': read_csv('adverse_media.csv'),
    }

def normalize_status(s):
    s=str(s)
    if 'Approved' in s: return 'Approved'
    if 'Reject' in s: return 'Rejected'
    if 'Document' in s or 'Re-upload' in s: return 'More Documents Required'
    if 'Review' in s or 'Pending' in s: return 'Manual Review Required'
    return s

def status_badge(status):
    st=normalize_status(status)
    if st=='Approved': return 'b-approved'
    if st=='Rejected': return 'b-reject'
    if 'Document' in st: return 'b-pending'
    if 'Review' in st or 'Pending' in st: return 'b-review'
    return 'b-neutral'

def get_user(request: Request):
    return request.session.get('user')

def require_login(request: Request):
    user=get_user(request)
    if not user:
        return None
    return user

def role_home(role):
    return '/staff/dashboard' if role=='staff' else '/customer/dashboard'

def get_customer(identifier):
    d=load_data(); c=d['customers']
    if c.empty: return None
    q=str(identifier).strip().lower()
    m=c[(c['case_id'].astype(str).str.lower()==q)|(c['customer_id'].astype(str).str.lower()==q)|(c['login_username'].astype(str).str.lower()==q)]
    return None if m.empty else m.iloc[0].to_dict()

def customer_context(identifier):
    d=load_data(); cust=get_customer(identifier)
    if not cust: return None
    cid=cust['customer_id']; case=cust['case_id']
    cust['profile_url'] = media_url(cust.get('profile_image_path'), 'avatar')
    docs=d['docs'][d['docs']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['docs'].empty else []
    files=d['files'][d['files']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['files'].empty else []
    for f in files:
        pth = f.get('preview_image_path') or f.get('file_path') or f.get('simulated_file_path')
        f['preview_url'] = media_url(pth, 'document')
        f['file_url'] = media_url(f.get('simulated_file_path') or pth, 'document')
        f['is_available'] = asset_exists(pth)
    hist=d['history'][d['history']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['history'].empty else []
    selfie=d['selfie'][d['selfie']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['selfie'].empty else []
    issues=[]
    for doc in docs:
        if str(doc.get('document_status','')).lower()!='passed': issues.append(f"{doc.get('document_type')}: {doc.get('document_status')}")
        if str(doc.get('quality_status','')).lower()!='passed': issues.append(f"{doc.get('document_type')}: quality {doc.get('quality_status')}")
        if str(doc.get('tampering_indicator','')).lower()!='not detected': issues.append(f"{doc.get('document_type')}: tampering indicator {doc.get('tampering_indicator')}")
    discrepancy=len(issues)
    decision = normalize_status(cust.get('case_status',''))
    return {'cust':cust,'docs':docs,'files':files,'hist':hist,'selfie':selfie,'issues':issues,'discrepancy':discrepancy,'decision':decision}



def customer_screening_summary(cid):
    d=load_data(); cid=str(cid)
    out={'sanctions':False,'pep':False,'fraud':False,'adverse':False,'notes':[]}
    s=d['sanctions']; p=d['pep']; f=d['fraud']; a=d['adverse']
    if not s.empty:
        r=s[s['customer_id'].astype(str)==cid]
        if not r.empty and int(r.iloc[0].get('sanctions_match',0) or 0)==1:
            out['sanctions']=True; out['notes'].append('Sanctions list match flagged')
        if not r.empty and int(r.iloc[0].get('high_risk_country',0) or 0)==1:
            out['notes'].append('High-risk country flagged')
    if not p.empty:
        r=p[p['customer_id'].astype(str)==cid]
        if not r.empty and int(r.iloc[0].get('pep_match',0) or 0)==1:
            out['pep']=True; out['notes'].append('PEP match flagged')
    if not f.empty:
        r=f[f['customer_id'].astype(str)==cid]
        if not r.empty:
            row=r.iloc[0]
            flags=[c for c in ['duplicate_mobile','duplicate_pan','duplicate_bank_account','repeated_kyc_attempt','synthetic_identity_signal'] if int(row.get(c,0) or 0)==1]
            if flags:
                out['fraud']=True; out['notes'].append('Fraud signal(s): '+', '.join(flags))
    if not a.empty:
        r=a[a['customer_id'].astype(str)==cid]
        if not r.empty and int(r.iloc[0].get('adverse_media_match',0) or 0)==1:
            out['adverse']=True; out['notes'].append('Adverse media match flagged')
    return out

def asset_exists(rel_path):
    if not rel_path:
        return False
    rel=str(rel_path).lstrip('/').replace('\\','/')
    return (BASE/rel).exists()

def media_url(rel_path, kind='document'):
    """Return a safe URL for customer/document images. Avoids broken images when only metadata exists for enterprise rows."""
    if rel_path and asset_exists(rel_path):
        return '/media/' + str(rel_path).lstrip('/').replace('\\','/')
    if kind == 'avatar':
        return '/static/img/avatar_placeholder.svg'
    return '/static/img/document_placeholder.svg'

def queue_df(status=None):
    c=load_data()['customers'].copy()
    if c.empty: return c
    c['normalized_status']=c['case_status'].apply(normalize_status)
    if status and status!='All': c=c[c['normalized_status']==status]
    return c

def metrics():
    c=queue_df()
    if c.empty: return {}
    return {
        'total': len(c),
        'approved': int((c['normalized_status']=='Approved').sum()),
        'review': int((c['normalized_status']=='Manual Review Required').sum()),
        'docs': int((c['normalized_status']=='More Documents Required').sum()),
        'rejected': int((c['normalized_status']=='Rejected').sum()),
        'high': int(c['synthetic_risk_profile'].astype(str).str.contains('High|Critical',case=False,na=False).sum()) if 'synthetic_risk_profile' in c else 0,
    }

templates.env.filters['badge'] = status_badge


def ops_insights():
    c=queue_df()
    m=metrics()
    total=max(m.get('total',0),1)
    dist=[
        {'label':'Approved','count':m.get('approved',0),'pct':round(m.get('approved',0)*100/total),'url':'/staff/queue?status=Approved','class':'ok'},
        {'label':'Manual Review','count':m.get('review',0),'pct':round(m.get('review',0)*100/total),'url':'/staff/queue?status=Manual Review Required','class':'warn'},
        {'label':'Document Remediation','count':m.get('docs',0),'pct':round(m.get('docs',0)*100/total),'url':'/staff/queue?status=More Documents Required','class':'info'},
        {'label':'Rejected / Escalated','count':m.get('rejected',0),'pct':round(m.get('rejected',0)*100/total),'url':'/staff/queue?status=Rejected','class':'bad'},
    ]
    if c.empty:
        return {'dist':dist,'channels':[],'states':[],'breach':0,'approval_rate':0}
    channels=[]
    if 'application_channel' in c.columns:
        for k,v in c['application_channel'].fillna('Unknown').value_counts().head(5).items():
            channels.append({'name':k,'count':int(v),'pct':round(int(v)*100/len(c))})
    states=[]
    if 'state' in c.columns:
        for k,v in c['state'].fillna('Unknown').value_counts().head(5).items():
            states.append({'name':k,'count':int(v),'pct':round(int(v)*100/len(c))})
    breach=int((pd.to_numeric(c.get('sla_hours',0), errors='coerce').fillna(0) <= 24).sum()) if 'sla_hours' in c else 0
    approval_rate=round(m.get('approved',0)*100/total)
    return {'dist':dist,'channels':channels,'states':states,'breach':breach,'approval_rate':approval_rate}

def row_priority(row):
    txt=(str(row.get('synthetic_risk_profile',''))+' '+str(row.get('case_status',''))).lower()
    if 'critical' in txt or 'reject' in txt: return 'P1'
    if 'high' in txt or 'review' in txt: return 'P2'
    if 'document' in txt or 'pending' in txt: return 'P3'
    return 'P4'

def enrich_rows(records):
    out=[]
    for r in records:
        r=dict(r)
        r['priority']=row_priority(r)
        st=normalize_status(r.get('case_status',''))
        if st=='Approved': r['stage']='Completed'
        elif st=='Manual Review Required': r['stage']='Human Review'
        elif st=='More Documents Required': r['stage']='Remediation'
        elif st=='Rejected': r['stage']='Closed - Rejected'
        else: r['stage']='Intake'
        out.append(r)
    return out

templates.env.filters['priority'] = row_priority


AGENT_CATALOG = [
    {
        'id':'document_intelligence',
        'name':'Document Intelligence Agent',
        'stage':'Data Extraction',
        'purpose':'Reads uploaded KYC documents, extracts name, DOB, address, ID numbers and validates document quality.',
        'inputs':'PAN, Aadhaar, passport, bank statement, salary slip, address proof, selfie',
        'checks':['OCR field extraction','Document type classification','Blur/quality validation','Tamper indicator check'],
        'output':'Structured document fields and document quality score',
        'icon':'📄'
    },
    {
        'id':'identity_verification',
        'name':'Identity Verification Agent',
        'stage':'Identity Resolution',
        'purpose':'Compares customer profile details against document fields and selfie/photo evidence.',
        'inputs':'Customer profile, document photo, selfie, extracted fields',
        'checks':['Name match','DOB match','Address match','Face/selfie confidence','Duplicate identity signal'],
        'output':'Identity match score and mismatch evidence',
        'icon':'🧑‍💼'
    },
    {
        'id':'compliance_screening',
        'name':'Compliance Screening Agent',
        'stage':'AML / Watchlist Screening',
        'purpose':'Screens customer against sanctions, PEP, adverse media and internal fraud references.',
        'inputs':'Name, DOB, address, nationality, transaction profile',
        'checks':['Sanctions screening','PEP screening','Adverse media scan','Internal watchlist lookup'],
        'output':'Compliance alert summary and screening disposition',
        'icon':'🛡️'
    },
    {
        'id':'financial_profile',
        'name':'Financial Profiling Agent',
        'stage':'Financial Due Diligence',
        'purpose':'Checks declared income, occupation, bank statement consistency and transaction behavior.',
        'inputs':'Income range, occupation, bank statement, transactions',
        'checks':['Income consistency','Average balance review','Transaction anomaly scan','Customer segment validation'],
        'output':'Financial risk profile and anomaly flags',
        'icon':'💳'
    },
    {
        'id':'fraud_intelligence',
        'name':'Fraud Intelligence Agent',
        'stage':'Fraud Detection',
        'purpose':'Detects forged documents, duplicate submissions, suspicious identity behavior and photo mismatch risk.',
        'inputs':'Document metadata, photo, selfie, device/channel signals',
        'checks':['Tampering indicator','Photo mismatch','Duplicate customer pattern','High-risk channel signal'],
        'output':'Fraud score and evidence flags',
        'icon':'🚨'
    },
    {
        'id':'risk_intelligence',
        'name':'Risk Intelligence Agent',
        'stage':'Risk Scoring',
        'purpose':'Combines all agent outputs and assigns explainable customer risk and target queue.',
        'inputs':'Document, identity, compliance, financial and fraud outputs',
        'checks':['Risk profile calculation','SLA priority','Queue assignment','Policy rule matching'],
        'output':'Low/Medium/High/Critical risk and routing recommendation',
        'icon':'📊'
    },
    {
        'id':'decision_reasoning',
        'name':'Decision Reasoning Agent',
        'stage':'Explainable Decision',
        'purpose':'Creates the final KYC decision with explanation and evidence pack for audit.',
        'inputs':'All agent outputs, policy rules, discrepancy count',
        'checks':['0 discrepancy approval','1-2 discrepancy human review','Missing document remediation','>2 discrepancy rejection'],
        'output':'Approve / Manual Review / More Documents Required / Reject with reason',
        'icon':'🧠'
    },
    {
        'id':'human_review',
        'name':'Human Review Agent',
        'stage':'Human-in-the-loop',
        'purpose':'Routes exception cases to staff, supports maker-checker review and captures reviewer decisions.',
        'inputs':'Case evidence, AI recommendation, reviewer notes',
        'checks':['Manual queue routing','Reviewer action capture','Manager escalation','Audit trail update'],
        'output':'Staff decision, escalation or closure action',
        'icon':'👥'
    },
    {
        'id':'notification_audit',
        'name':'Notification & Audit Agent',
        'stage':'Communication & Governance',
        'purpose':'Generates customer/staff notifications and maintains evidence, trace logs and audit records.',
        'inputs':'Decision output, case status, reviewer actions',
        'checks':['Customer notification','Staff notification','Evidence pack','Decision trace log'],
        'output':'Email/message content and auditable evidence trail',
        'icon':'✉️'
    },
]

def agent_run_for_case(ctx):
    if not ctx:
        return []
    cust=ctx['cust']; docs=ctx['docs']; issues=ctx['issues']; decision=ctx['decision']
    issue_count=len(issues)
    doc_count=len(docs)
    # stable, explainable confidence values for demo
    base_quality=max(62, 96 - issue_count*8)
    compliance_conf=92 if 'Rejected' not in decision else 71
    identity_conf=94 if issue_count==0 else max(65, 90 - issue_count*7)
    results=[]
    for a in AGENT_CATALOG:
        aid=a['id']
        status='Completed'
        confidence=base_quality
        finding='No blocking issue detected.'
        evidence=[]
        if aid=='document_intelligence':
            confidence=max(60, 98 - issue_count*6)
            finding=f'{doc_count} document records assessed. {issue_count} issue(s) detected across document quality/matching checks.'
            evidence=[f'Documents assessed: {doc_count}', f'Issue count: {issue_count}', 'Mandatory set: PAN, Aadhaar, bank statement, salary slip, address proof']
        elif aid=='identity_verification':
            confidence=identity_conf
            finding='Identity fields and photo/selfie evidence reviewed.' if issue_count<3 else 'Multiple identity/document mismatches require rejection or escalation.'
            evidence=['Name/DOB/address consistency checked', 'Selfie/photo confidence verified', 'Duplicate identity pattern checked']
        elif aid=='compliance_screening':
            confidence=compliance_conf
            finding='Sanctions, PEP and adverse media checks completed with explainable screening result.'
            evidence=['Sanctions list: checked', 'PEP list: checked', 'Adverse media: checked']
        elif aid=='financial_profile':
            confidence=88 if str(cust.get('income_range','')).lower() else 74
            finding=f"Financial profile validated for occupation '{cust.get('occupation','N/A')}' and income range '{cust.get('income_range','N/A')}'."
            evidence=['Income declaration reviewed', 'Bank statement summary assessed', 'Transaction anomaly scan completed']
        elif aid=='fraud_intelligence':
            confidence=max(58, 94 - issue_count*9)
            finding='No major fraud pattern detected.' if issue_count<=2 else 'High mismatch/tamper signal found; rejection/escalation recommended.'
            evidence=['Tamper indicator checked', 'Photo mismatch checked', 'Duplicate submission pattern checked']
        elif aid=='risk_intelligence':
            confidence=90
            finding=f"Risk profile: {cust.get('synthetic_risk_profile','Low')}. Queue: {cust.get('assigned_queue','KYC Operations')}."
            evidence=[f"Risk profile: {cust.get('synthetic_risk_profile','Low')}", f"SLA hours: {cust.get('sla_hours','N/A')}", f"Assigned queue: {cust.get('assigned_queue','N/A')}"]
        elif aid=='decision_reasoning':
            confidence=93
            finding=f'Final AI recommendation: {decision}. Rule applied using discrepancy count and document status.'
            evidence=['0 discrepancy = Approved', '1-2 discrepancies = Manual Review', 'Missing/invalid document = Remediation', '>2 discrepancies = Rejected']
        elif aid=='human_review':
            status='Ready' if decision!='Approved' else 'Not Required'
            confidence=85
            finding='Human review available for exception handling and maker-checker decisioning.'
            evidence=['Reviewer action capture enabled', 'Escalation control available', 'Audit note required']
        elif aid=='notification_audit':
            confidence=96
            finding='Notification and evidence trace generated for customer and staff visibility.'
            evidence=['Customer notification template ready', 'Staff action log enabled', 'Evidence pack available']
        results.append({**a,'status':status,'confidence':int(confidence),'finding':finding,'evidence':evidence})
    return results



# Extra agents from the original TrustShield workflow so the FastAPI app preserves the full AGENTS_002 concept.
AGENT_CATALOG += [
    {
        'id':'pii_masking', 'name':'Selective PII Masking Agent', 'stage':'Privacy Protection',
        'purpose':'Masks sensitive customer fields before display, logs or evidence sharing while keeping operational fields usable.',
        'inputs':'Name, mobile, email, address, ID numbers, uploaded document fields',
        'checks':['Mask ID numbers','Mask email/mobile for non-required views','Protect raw document values','Preserve audit-safe evidence'],
        'output':'Privacy-safe customer and document view', 'icon':'🔐'
    },
    {
        'id':'compliance_rag', 'name':'Compliance RAG Agent', 'stage':'Policy Retrieval',
        'purpose':'Retrieves KYC policy rules and applies them to decision explanation, remediation, escalation and evidence pack creation.',
        'inputs':'KYC policy knowledge base, document rules, discrepancy count, risk profile',
        'checks':['Policy rule retrieval','Mandatory document policy','Discrepancy threshold rule','Explainable control mapping'],
        'output':'Policy-backed decision rationale', 'icon':'📚'
    },
    {
        'id':'aml_sanctions', 'name':'AML & Sanctions Screening Agent', 'stage':'Regulatory Screening',
        'purpose':'Checks sanctions, PEP and AML risk signals and routes cases to compliance if a potential hit is found.',
        'inputs':'Customer identity, nationality, address, watchlists and screening references',
        'checks':['AML risk scan','Sanctions screening','PEP screening','False-positive handling'],
        'output':'AML/PEP/sanctions disposition', 'icon':'🌐'
    },
    {
        'id':'adverse_media', 'name':'Adverse Media Intelligence Agent', 'stage':'Reputation Screening',
        'purpose':'Finds and summarizes adverse news/media risk indicators and adds explainable signals to the risk score.',
        'inputs':'Customer/entity name, city, adverse media dataset, risk tags',
        'checks':['Adverse media hit check','Risk category tagging','Entity ambiguity handling','Reviewer evidence note'],
        'output':'Adverse media risk summary', 'icon':'📰'
    },

    {
        'id':'notification_email', 'name':'Notification & Email Agent', 'stage':'Customer Communication',
        'purpose':'Creates customer and staff email notifications for approval, re-upload request, manual review, rejection and escalation updates.',
        'inputs':'Decision output, case status, discrepancy reason, customer contact, staff queue',
        'checks':['Customer approval email','Re-upload request email','Staff queue notification','Escalation alert'],
        'output':'Role-aware email and notification content', 'icon':'📨'
    },
    {
        'id':'audit_governance', 'name':'Audit & Governance Agent', 'stage':'Governance',
        'purpose':'Creates traceable audit logs, evidence packs and decision history for regulatory review.',
        'inputs':'All agent outputs, reviewer decisions, notification actions and case status changes',
        'checks':['Trace file generation','Evidence pack readiness','Reviewer note capture','Decision immutability check'],
        'output':'Audit trail and governance evidence', 'icon':'🧾'
    }
]

# Compatibility routes for notebook/proxy tools that still check Streamlit-style endpoints.
# This app is FastAPI, so these endpoints are not used by the UI, but returning 200 avoids confusing 404 logs.
@app.get('/_stcore/health')
def streamlit_health_compat():
    return {'status': 'ok', 'app': 'TrustShield FastAPI'}

@app.get('/_stcore/host-config')
def streamlit_host_config_compat():
    return {'server': 'fastapi', 'websocketCompression': False}

@app.get('/favicon.ico')
def favicon():
    return JSONResponse({}, status_code=204)

@app.get('/api/health')
def api_health():
    return {'status':'ok','app':'TrustShield KYC','version':'v14','customers': metrics().get('total',0), 'gemini_configured': bool(API_KEY and API_KEY not in ('your_gemini_api_key_here','paste_your_key_here'))}

@app.get('/')
def root(request: Request):
    user=get_user(request)
    if user: return RedirectResponse(role_home(user['role']),303)
    return templates.TemplateResponse(request, 'login.html', {'request':request,'user':None})

@app.post('/login')
def login(request: Request, username: str=Form(...), password: str=Form(...)):
    u=username.strip(); p=password.strip()
    if p!='Trust@123':
        return templates.TemplateResponse(request, 'login.html', {'request':request,'user':None,'error':'Invalid username or password.'})
    if u.lower()=='staff':
        request.session['user']={'role':'staff','username':'staff','name':'KYC Operations Staff'}
        return RedirectResponse('/staff/dashboard',303)
    cust=get_customer(u)
    if cust:
        request.session['user']={'role':'customer','username':cust['login_username'],'customer_id':cust['customer_id'],'case_id':cust['case_id'],'name':cust['full_name']}
        return RedirectResponse('/customer/dashboard',303)
    return templates.TemplateResponse(request, 'login.html', {'request':request,'user':None,'error':'Invalid username or password.'})

@app.get('/logout')
def logout(request: Request):
    request.session.clear(); return RedirectResponse('/',303)

@app.get('/staff/dashboard')
def staff_dashboard(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    d=load_data(); recent=enrich_rows(queue_df().head(10).to_dict('records'))
    return templates.TemplateResponse(request, 'staff_dashboard.html', {'request':request,'user':user,'active':'dashboard','m':metrics(),'insights':ops_insights(),'recent':recent})

@app.get('/staff/queue')
def staff_queue(request: Request, status: str='All', q: str=''):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    df=queue_df(status)
    if q:
        ql=q.lower(); df=df[df.apply(lambda r: ql in ' '.join(map(str,r.values)).lower(), axis=1)]
    rows=enrich_rows(df.head(200).to_dict('records'))
    return templates.TemplateResponse(request, 'case_queue.html', {'request':request,'user':user,'active':'queue','rows':rows,'status':status,'q':q,'m':metrics(),'insights':ops_insights()})

@app.get('/staff/case/{case_id}')
def case_profile(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id)
    if not ctx: return templates.TemplateResponse(request, 'message.html', {'request':request,'user':user,'title':'Case not found','message':'The selected case was not found.'})
    return templates.TemplateResponse(request, 'case_profile.html', {'request':request,'user':user,'active':'profile','insights':ops_insights(),'catalog':AGENT_CATALOG,'agents':agent_run_for_case(ctx),**ctx})

@app.post('/staff/case/{case_id}/action')
def case_action(request: Request, case_id: str, action: str=Form(...), note: str=Form('')):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    p=BASE/'outputs'/'audit_logs'/'staff_actions.log'
    with p.open('a', encoding='utf-8') as f: f.write(f"{datetime.now().isoformat()} | {user['username']} | {case_id} | {action} | {note}\n")
    return RedirectResponse(f'/staff/case/{case_id}?saved=1',303)

@app.get('/staff/agent-review')
def agent_review(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id) or customer_context('CASE001')
    agents=agent_run_for_case(ctx)
    return templates.TemplateResponse(request, 'agent_review.html', {'request':request,'user':user,'active':'agent','ctx':ctx,'agents':agents,'catalog':AGENT_CATALOG,'m':metrics()})

@app.get('/staff/agents')
def agent_command_center(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id) or customer_context('CASE001')
    agents=agent_run_for_case(ctx)
    return templates.TemplateResponse(request, 'agents_command.html', {'request':request,'user':user,'active':'agent','ctx':ctx,'agents':agents,'catalog':AGENT_CATALOG,'m':metrics(),'insights':ops_insights()})



def create_agent_execution_trace(ctx):
    """Run the separate ai_agents folder orchestration.
    Falls back to internal catalog only if the agent package is unavailable."""
    try:
        from ai_agents.orchestrator.orchestrator_agent import OrchestratorAgent
        trace = OrchestratorAgent(BASE).run(ctx)
        # also mirror trace to outputs/agent_traces for existing audit pages
        out_dir = BASE/'outputs'/'agent_traces'
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir/f"{trace['run_id']}.json").write_text(json.dumps(trace, indent=2, default=str), encoding='utf-8')
        return trace
    except Exception:
        agents = agent_run_for_case(ctx)
        case_id = ctx['cust']['case_id']
        now = datetime.now().isoformat(timespec='seconds')
        workflow_steps = []
        for i, a in enumerate(agents, start=1):
            workflow_steps.append({
                'sequence': i, 'agent_id': a['id'], 'agent_name': a['name'], 'stage': a['stage'],
                'status': a['status'], 'confidence': a['confidence'], 'finding': a['finding'],
                'evidence': a.get('evidence', []), 'output': a.get('output',''), 'timestamp': now,
            })
        trace = {
            'run_id': f"RUN-{case_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'case_id': case_id, 'customer_id': ctx['cust']['customer_id'], 'customer_name': ctx['cust']['full_name'],
            'decision': ctx['decision'], 'discrepancy_count': ctx['discrepancy'],
            'risk_profile': ctx['cust'].get('synthetic_risk_profile','N/A'),
            'agent_count': len(workflow_steps),
            'completed_agents': sum(1 for x in workflow_steps if x['status'] == 'Completed'),
            'requires_human_review': ctx['decision'] != 'Approved', 'generated_at': now, 'workflow': workflow_steps,
        }
        out_dir = BASE/'outputs'/'agent_traces'
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir/f"{trace['run_id']}.json").write_text(json.dumps(trace, indent=2, default=str), encoding='utf-8')
        return trace

@app.get('/api/agents/{case_id}')
def agents_api(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return JSONResponse({'error':'unauthorized'},401)
    ctx=customer_context(case_id)
    if not ctx: return JSONResponse({'error':'case not found'},404)
    trace = create_agent_execution_trace(ctx)
    return trace

@app.post('/api/agents/{case_id}/run')
def run_agents_api(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return JSONResponse({'error':'unauthorized'},401)
    ctx=customer_context(case_id)
    if not ctx: return JSONResponse({'error':'case not found'},404)
    trace = create_agent_execution_trace(ctx)
    audit_dir = BASE/'outputs'/'audit_logs'
    audit_dir.mkdir(parents=True, exist_ok=True)
    with (audit_dir/'agent_runs.log').open('a', encoding='utf-8') as f:
        f.write(f"{trace['generated_at']} | {user.get('username')} | {trace['run_id']} | {case_id} | {trace['decision']} | {trace['agent_count']} agents\n")
    return trace

@app.get('/staff/risk')
def risk(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    df=enrich_rows(queue_df().head(120).to_dict('records'))
    return templates.TemplateResponse(request, 'risk_guardrail.html', {'request':request,'user':user,'active':'risk','rows':df,'m':metrics(),'insights':ops_insights()})

@app.get('/staff/human-review')
def human_review(request: Request):
    return staff_queue(request, status='Manual Review Required')

@app.get('/staff/notifications')
def notifications(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    examples=[{'to':'customer','title':'KYC approved','body':'Your KYC verification has been approved.'},{'to':'customer','title':'Document re-upload required','body':'Please upload a clearer salary slip/address proof.'},{'to':'staff','title':'Manual review assigned','body':'A case with two discrepancies requires review.'}]
    return templates.TemplateResponse(request, 'notification_email_center.html', {'request':request,'user':user,'active':'notifications','examples':examples})

@app.get('/staff/audit')
def audit(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    hist=load_data()['history'].head(50).to_dict('records')
    return templates.TemplateResponse(request, 'audit_evidence_pack.html', {'request':request,'user':user,'active':'audit','hist':hist})

@app.get('/staff/closure')
def closure(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    rows=queue_df().tail(40).to_dict('records')
    return templates.TemplateResponse(request, 'case_closure_full.html', {'request':request,'user':user,'active':'closure','rows':rows})



@app.get('/staff/onboarding')
def staff_onboarding_alias(request: Request):
    return staff_customer_registration(request)

@app.get('/staff/customer-registration')
def staff_customer_registration(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    return templates.TemplateResponse(request, 'staff_customer_registration.html', {'request':request,'user':user,'active':'customer_registration'})

@app.get('/staff/document-upload-checklist')
def document_upload_checklist(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id) or customer_context('CASE001')
    return templates.TemplateResponse(request, 'document_upload_checklist.html', {'request':request,'user':user,'active':'document_upload','case_id':case_id,'ctx':ctx})

@app.get('/staff/photo-document-preview')
def photo_document_preview(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id) or customer_context('CASE001')
    return templates.TemplateResponse(request, 'photo_document_preview.html', {'request':request,'user':user,'active':'preview','case_id':case_id,'ctx':ctx})

@app.get('/staff/multi-agent-review')
def multi_agent_review_alias(request: Request, case_id: str='CASE001'):
    return agent_command_center(request, case_id)

@app.get('/staff/risk-guardrail-intelligence')
def risk_guardrail_alias(request: Request):
    return risk(request)

@app.get('/staff/human-review-workflow')
def human_review_workflow(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id) or customer_context('CASE001')
    return templates.TemplateResponse(request, 'human_review_workflow.html', {'request':request,'user':user,'active':'human_review','case_id':case_id,'ctx':ctx})

@app.get('/staff/notification-email-center')
def notification_email_center_alias(request: Request):
    return notifications(request)

@app.get('/staff/audit-evidence-pack')
def audit_evidence_pack_alias(request: Request):
    return audit(request)

@app.get('/staff/case-closure')
def case_closure_alias(request: Request):
    return closure(request)

@app.get('/customer/dashboard')
def customer_dashboard(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_dashboard.html', {'request':request,'user':user,'active':'customer_dashboard',**ctx})

@app.get('/customer/register')
def register_page(request: Request):
    user=get_user(request) or {'role':'guest','name':'New Applicant'}
    return templates.TemplateResponse(request, 'register.html', {'request':request,'user':user,'active':'register'})

@app.post('/customer/register')
def register_customer(request: Request, full_name: str=Form(...), email: str=Form(...), mobile: str=Form(...), dob: str=Form(...), gender: str=Form(...), address: str=Form(...), city: str=Form(...), state: str=Form(...), occupation: str=Form(...), income_range: str=Form(...), policy: str=Form('Standard Onboarding')):
    customers=read_csv('customers.csv')
    n=len(customers)+1
    cid=f'CUST{n:04d}'; case=f'CASE{n:04d}'; username=f'cust{n:04d}'
    status_map={'Low Risk - Straight Through Processing':'Approved','Identity Review - Single Data Mismatch':'Manual Review Required','Enhanced Due Diligence - Two Data Mismatches':'Manual Review Required','Document Remediation - Missing Mandatory Document':'More Documents Required','Standard Onboarding - AI Risk Assessment':'Manual Review Required'}
    new={'case_id':case,'customer_id':cid,'login_username':username,'full_name':full_name,'dob':dob,'gender':gender,'email':email,'mobile':mobile,'address':address,'city':city,'state':state,'country':'India','nationality':'Indian','occupation':occupation,'income_range':income_range,'customer_type':'Retail','application_channel':'Customer Portal','application_date':datetime.now().date().isoformat(),'case_status':status_map.get(policy,'Manual Review Required'),'assigned_queue':'Onboarding Queue','sla_hours':72,'synthetic_risk_profile':'Low','profile_image_path':'uploads/customer_uploaded_documents/.gitkeep'}
    customers=pd.concat([customers, pd.DataFrame([new])], ignore_index=True)
    customers.to_csv(BASE/'data'/'customers.csv', index=False)
    request.session['last_registered']={'case_id':case,'customer_id':cid,'username':username,'password':'Trust@123'}
    return RedirectResponse('/customer/upload',303)

@app.get('/customer/upload')
def upload_page(request: Request):
    user=get_user(request) or {'role':'guest','name':'New Applicant'}
    last=request.session.get('last_registered')
    return templates.TemplateResponse(request, 'upload.html', {'request':request,'user':user,'active':'upload','last':last,'saved':None})

@app.post('/customer/upload')
async def upload_docs(request: Request, files: list[UploadFile]=File(default=[])):
    last=request.session.get('last_registered') or {'customer_id':'NEW'}
    out=BASE/'uploads'/'customer_uploaded_documents'/last.get('customer_id','NEW')
    out.mkdir(parents=True, exist_ok=True)
    saved=[]
    for f in files:
        if f.filename:
            dest=out/f.filename
            with dest.open('wb') as w: shutil.copyfileobj(f.file,w)
            saved.append(f.filename)
    return templates.TemplateResponse(request, 'upload.html', {'request':request,'user':get_user(request) or {'role':'guest','name':'New Applicant'},'active':'upload','last':last,'saved':saved})


@app.get('/customer/profile')
def customer_profile_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_profile_page.html', {'request':request,'user':user,'active':'customer_profile',**ctx})

@app.get('/customer/photo-selfie')
def customer_photo_selfie(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_photo_selfie.html', {'request':request,'user':user,'active':'customer_photo',**ctx})

@app.get('/customer/status')
def customer_status_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    stages=['Application Submitted','Documents Uploaded','AI Agent Validation','Compliance Screening','Human Review / Decision','Closure']
    return templates.TemplateResponse(request, 'customer_status_page.html', {'request':request,'user':user,'active':'customer_status','stages':stages,**ctx})

@app.get('/customer/checklist')
def customer_checklist_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    required=['PAN Card','Aadhaar Card','Bank Statement','Salary Slip','Address Proof','Passport','Driving License','Voter ID']
    return templates.TemplateResponse(request, 'customer_checklist_page.html', {'request':request,'user':user,'active':'customer_checklist','required':required,**ctx})

@app.get('/customer/request-status')
def customer_request_status(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_request_status.html', {'request':request,'user':user,'active':'customer_request',**ctx})

@app.get('/customer/notifications')
def customer_notifications(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    notes=[
        {'title':'Application received','body':'Your KYC application has been received and assigned a case ID.'},
        {'title':'AI verification completed','body':'Document intelligence and identity verification checks have been completed.'},
        {'title':'Next action','body':f"Current status: {ctx['decision'] if ctx else 'Pending'}."},
    ]
    return templates.TemplateResponse(request, 'customer_notifications.html', {'request':request,'user':user,'active':'customer_notifications','notes':notes,**ctx})

@app.get('/customer/final-decision')
def customer_final_decision(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_final_decision.html', {'request':request,'user':user,'active':'customer_final',**ctx})


@app.get('/staff/orchestrator')
def orchestrator_console(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    workflow=[
        'Customer KYC Portal','Multimodal Upload Layer','OCR + Document Intelligence Layer','Selective PII Masking Layer','Master Orchestrator Agent','Document Intelligence Agent','Identity Verification Agent','Compliance RAG Agent','AML & Sanctions Screening Agent','Adverse Media Intelligence Agent','Financial Profiling Agent','Fraud Intelligence Agent','Risk Intelligence Agent','Decision Reasoning Agent','Notification & Email Agent','Human Review Agent','Audit & Governance Agent','Shared Agent Memory Bus','RAG Knowledge Retrieval + Vector Database','Explainable Decision Engine','Human Review Workflow','Email Notification + Audit Trail','Final KYC Evidence Pack'
    ]
    return templates.TemplateResponse(request, 'orchestrator.html', {'request':request,'user':user,'active':'orchestrator','workflow':workflow,'catalog':AGENT_CATALOG,'m':metrics()})

@app.get('/staff/memory-rag')
def memory_rag_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    policy_path=BASE/'data'/'kyc_policy_knowledge.txt'
    policy=policy_path.read_text(encoding='utf-8', errors='ignore') if policy_path.exists() else 'KYC policy knowledge base not found.'
    return templates.TemplateResponse(request, 'memory_rag.html', {'request':request,'user':user,'active':'memory','policy':policy,'m':metrics()})

@app.get('/staff/original-workflow')
def original_workflow_page(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    workflow=[
        'Customer onboarding request','Multimodal document upload layer','OCR + Document Intelligence','Selective PII masking','Master Orchestrator Agent','Document Intelligence Agent','Identity Verification Agent','Compliance RAG Agent','AML & Sanctions Screening Agent','Adverse Media Intelligence Agent','Financial Profiling Agent','Fraud Intelligence Agent','Risk Intelligence Agent','Decision Reasoning Agent','Notification & Email Agent','Human Review Agent','Audit & Governance Agent','Shared Agent Memory Bus','RAG Knowledge Retrieval + Vector Database','Explainable Decision Engine','Human Review Workflow','Email Notification + Audit Trail','Final KYC Evidence Pack'
    ]
    return templates.TemplateResponse(request, 'original_workflow.html', {'request':request,'user':user,'active':'workflow','workflow':workflow,'catalog':AGENT_CATALOG,'m':metrics()})

@app.get('/api/pipeline/{case_id}')
def pipeline_api(request: Request, case_id: str):
    user=require_login(request)
    if not user: return JSONResponse({'error':'unauthorized'},401)
    ctx=customer_context(case_id)
    if not ctx: return JSONResponse({'error':'case not found'},404)
    return {'case_id':ctx['cust']['case_id'],'workflow':['intake','document_intelligence','pii_masking','identity_verification','compliance_rag','aml_sanctions','adverse_media','financial_profile','fraud_intelligence','risk_intelligence','decision_reasoning','human_review','notification_audit','audit_governance'],'decision':ctx['decision'],'agents':agent_run_for_case(ctx)}

@app.get('/media/{path:path}')
def media(path:str):
    p=BASE/path
    if p.exists(): return FileResponse(p)
    return JSONResponse({'error':'not found'},404)

def portfolio_screening_counts():
    d=load_data()
    s=d['sanctions']; p=d['pep']; f=d['fraud']; a=d['adverse']
    out={'sanctions':0,'high_risk_country':0,'pep':0,'adverse':0,'fraud':0}
    if not s.empty:
        if 'sanctions_match' in s: out['sanctions']=int(pd.to_numeric(s['sanctions_match'],errors='coerce').fillna(0).eq(1).sum())
        if 'high_risk_country' in s: out['high_risk_country']=int(pd.to_numeric(s['high_risk_country'],errors='coerce').fillna(0).eq(1).sum())
    if not p.empty and 'pep_match' in p:
        out['pep']=int(pd.to_numeric(p['pep_match'],errors='coerce').fillna(0).eq(1).sum())
    if not a.empty and 'adverse_media_match' in a:
        out['adverse']=int(pd.to_numeric(a['adverse_media_match'],errors='coerce').fillna(0).eq(1).sum())
    if not f.empty:
        flags=[c for c in ['duplicate_mobile','duplicate_pan','duplicate_bank_account','repeated_kyc_attempt','synthetic_identity_signal'] if c in f]
        if flags:
            out['fraud']=int((pd.to_numeric(f[flags].stack(),errors='coerce').fillna(0)==1).sum())
    return out

def fallback_answer(user, q):
    ql = q.lower().strip()
    d = load_data(); m = metrics()
    role = (user or {}).get('role','guest')

    # ---- Universal small talk ----
    greetings = ('hi','hello','hey','hiya','namaste','good morning','good afternoon','good evening','yo')
    if any(ql==g or ql.startswith(g+' ') or ql.startswith(g+',') or ql.startswith(g+'!') for g in greetings):
        if role=='customer':
            ctx=customer_context(user.get('customer_id'))
            name=ctx['cust']['full_name'].split(' ')[0] if ctx else 'there'
            return f"Hello {name}! I'm your TrustShield assistant. I can check your KYC status, list required documents, explain why a case is in review, and tell you what to do next. What would you like to know?"
        if role=='staff':
            return "Hello! I'm your TrustShield operations assistant. Ask me about portfolio metrics, case queues, a specific Case/Customer ID, AML/PEP/fraud screening, SLA breaches or decision rules."
        return "Hello! Sign in to get personalized KYC help, or ask a general question about TrustShield KYC."

    if any(t in ql for t in ('thank you','thanks','thx','appreciate it','great job','awesome')):
        return "You're welcome! Let me know if there's anything else about your KYC case or the platform I can help with."

    if ql in ('?','help','menu','what can you do','what can you do?','options','commands'):
        if role=='customer':
            return ("I can help with:\n"
                    "• My KYC status — \"What is my KYC status?\"\n"
                    "• Required documents — \"What documents do I need?\"\n"
                    "• Review reasons — \"Why is my case in review?\"\n"
                    "• Screening results — \"Any sanctions or PEP flags on my case?\"\n"
                    "• Timelines — \"How long will my KYC take?\"\n"
                    "• Support — \"How do I contact support?\"")
        return ("I can help staff with:\n"
                "• Portfolio overview — \"Portfolio summary\" / \"How many customers?\"\n"
                "• Case lookup — \"Status of CASE0007\" or \"Show CUST0012\"\n"
                "• Queues — \"How many in manual review?\" / \"Document remediation count\"\n"
                "• Decision rules — \"What is the approval rule?\"\n"
                "• Risk & screening — \"High risk cases\", \"Sanctions hits\", \"PEP matches\", \"Fraud signals\"\n"
                "• SLA — \"SLA breaches today\"\n"
                "• AI agents — \"How many AI agents run per case?\"")

    # ---- Case / Customer ID lookup (works for both roles, scoped) ----
    id_match = re.search(r'\b(CASE\s?-?\s?0*\d+|CUST\s?-?\s?0*\d+)\b', q, re.I)
    if id_match:
        raw=re.sub(r'\s|-', '', id_match.group(1)).upper()
        idm=re.match(r'(CASE|CUST)0*(\d+)', raw)
        ctx=None
        if idm:
            prefix,num=idm.groups()
            for cand in (f"{prefix}{num.zfill(3)}", f"{prefix}{num.zfill(4)}", f"{prefix}{num}"):
                ctx=customer_context(cand)
                if ctx:
                    raw=cand
                    break
        if role=='customer':
            own_ctx=customer_context(user.get('customer_id'))
            own_case=str(own_ctx['cust']['case_id']).upper() if own_ctx else ''
            own_cust=str(own_ctx['cust']['customer_id']).upper() if own_ctx else ''
            if raw not in (own_case, own_cust):
                return "I can only share details about your own case. Ask me \"What is my KYC status?\" for your case information."
            ctx=own_ctx
        if not ctx:
            return f"I couldn't find a case or customer matching '{raw}'. Double-check the ID and try again."
        cust=ctx['cust']; sc=customer_screening_summary(cust['customer_id'])
        flags='None' if not sc['notes'] else '; '.join(sc['notes'])
        return (f"{cust['full_name']} — Case {cust['case_id']} ({cust['customer_id']})\n"
                f"Status: {ctx['decision']} | Risk: {cust.get('synthetic_risk_profile','N/A')} | Queue: {cust.get('assigned_queue','N/A')} | SLA: {cust.get('sla_hours','N/A')}h\n"
                f"Discrepancies: {ctx['discrepancy']} | Screening flags: {flags}")

    # ---- Customer-facing intents ----
    if role=='customer':
        ctx=customer_context(user.get('customer_id'))
        if not ctx: return 'I could not find your customer case. Please contact support.'
        cust=ctx['cust']; sc=customer_screening_summary(cust['customer_id'])

        if any(k in ql for k in ('status','kyc','decision','progress','approved','where do i stand','application')):
            extra = '' if ctx['decision']=='Approved' else f" It is currently assigned to {cust.get('assigned_queue','our operations team')} with an SLA of {cust.get('sla_hours','N/A')} hours."
            return f"Your KYC status is '{ctx['decision']}' for case {cust['case_id']}.{extra}"

        if any(k in ql for k in ('document','upload','checklist','missing','pending','re-upload','reupload')):
            if ctx['issues']:
                return ("I found the following document issue(s) on your case:\n- " + "\n- ".join(ctx['issues']) +
                        "\nPlease go to 'Upload Documents' to re-submit a clear, valid copy.")
            return f"All {len(ctx['docs'])} document records on file look fine. Required documents are PAN, Aadhaar, bank statement, salary slip and address proof — check the 'Document Checklist' page for the full list."

        if any(k in ql for k in ('why','reject','reason','review','escalat','hold')):
            if ctx['discrepancy']==0:
                return "Your case has no open discrepancies. If it still shows 'Manual Review Required', our team is doing a final quality check before approval."
            return (f"Your case has {ctx['discrepancy']} discrepancy/discrepancies that triggered manual review:\n- " + "\n- ".join(ctx['issues']) +
                    "\nResolving these (usually by re-uploading a clearer document) can speed up your decision.")

        if any(k in ql for k in ('sanction','pep','screen','aml','adverse','watchlist')):
            if not sc['notes']:
                return "Good news — your case has no sanctions, PEP or adverse-media flags. Screening is clear."
            return "Your case has the following screening note(s): " + "; ".join(sc['notes']) + ". Our compliance team will review this as part of your case."

        if any(k in ql for k in ('risk',)):
            return f"Your current risk profile is '{cust.get('synthetic_risk_profile','Low')}'. This is based on document quality, identity match, screening results and your declared profile."

        if any(k in ql for k in ('sla','how long','when will','time','eta','duration')):
            return f"Your case is assigned to {cust.get('assigned_queue','our operations team')} with a target SLA of {cust.get('sla_hours','N/A')} hours from submission. You'll be notified as soon as a decision is made."

        if any(k in ql for k in ('contact','support','help','phone','email','reach','agent')):
            return "For further help, use the 'Notifications' page for updates on your case, or contact TrustShield support at support@trustshield-kyc.example. Your reference is case " + str(cust['case_id']) + "."

        return (f"I can help with your KYC status, required documents, the reason for review, screening results, timelines and support. "
                f"Your case ID is {cust['case_id']} and current status is '{ctx['decision']}'.")

    # ---- Staff-facing intents ----
    insights = ops_insights()
    if any(k in ql for k in ('portfolio','total','how many customer','customer count','overview','summary')):
        return (f"Portfolio summary: {m.get('total',0)} customers — {m.get('approved',0)} approved, "
                f"{m.get('review',0)} in manual review, {m.get('docs',0)} awaiting documents, "
                f"{m.get('rejected',0)} rejected. Approval rate ~{insights.get('approval_rate',0)}%.")

    if any(k in ql for k in ('rule','approve','policy','criteria','threshold')):
        return ('Decision rule: 0 discrepancies = Approve, 1-2 discrepancies = Manual Review, '
                'a missing/invalid mandatory document = Document Remediation, more than 2 discrepancies = Reject/Escalate. '
                'See the Memory & RAG page for the full policy text.')

    if any(k in ql for k in ('manual review','review queue','in review')):
        return f"There are {m.get('review',0)} cases in Manual Review Required. Open Case Workbench and filter by that status to start working through them."

    if any(k in ql for k in ('document remediation','more document','missing document','re-upload queue')):
        return f"There are {m.get('docs',0)} cases waiting on 'More Documents Required'. These need a customer re-upload before they can proceed."

    if 'reject' in ql or 'escalat' in ql:
        return f"There are {m.get('rejected',0)} rejected/escalated cases out of {m.get('total',0)} total."

    if any(k in ql for k in ('sla','breach','overdue','late')):
        return f"{insights.get('breach',0)} case(s) currently have an SLA of 24 hours or less remaining — prioritize these in the Case Workbench."

    if 'risk' in ql:
        return f"There are {m.get('high',0)} High/Critical risk cases out of {m.get('total',0)}. Open Risk Intelligence to review them with explainable scoring."

    if any(k in ql for k in ('sanction','pep','aml','adverse','fraud','watchlist','screen')):
        sc=portfolio_screening_counts()
        return (f"Screening snapshot across the portfolio: {sc['sanctions']} sanctions match(es), "
                f"{sc['pep']} PEP match(es), {sc['adverse']} adverse-media match(es), "
                f"{sc['high_risk_country']} high-risk-country flag(s), and {sc['fraud']} fraud signal(s). "
                f"Open AML & Sanctions Screening or Adverse Media agents on a case for details.")

    if 'agent' in ql or 'ai' in ql or 'orchestrat' in ql:
        return (f"TrustShield runs {len(AGENT_CATALOG)} specialized AI agents per case — document intelligence, identity "
                f"verification, PII masking, compliance RAG, AML/sanctions, adverse media, financial profiling, fraud "
                f"intelligence, risk intelligence, decision reasoning, human review and notification/audit. Run them from "
                f"any case profile or the AI Agents Command Center.")

    if any(k in ql for k in ('channel','source','application channel')):
        if insights.get('channels'):
            top=', '.join(f"{c['name']} ({c['count']})" for c in insights['channels'][:3])
            return f"Top application channels: {top}."
        return "Channel breakdown is not available for this dataset."

    if any(k in ql for k in ('state','location','region','geograph')):
        if insights.get('states'):
            top=', '.join(f"{s['name']} ({s['count']})" for s in insights['states'][:3])
            return f"Top customer states: {top}."
        return "State/region breakdown is not available for this dataset."

    return ('I can help with AI agent orchestration, case/customer lookup (try "status of CASE0007"), '
            'case queues, approval rules, risk and screening summaries, SLA breaches, and notifications/audit. '
            'Type "help" to see everything I can do.')

@app.post('/api/chat')
async def chat_api(request: Request):
    user=get_user(request) or {'role':'guest'}
    try:
        data=await request.json()
    except Exception:
        data={}
    question=str(data.get('question','')).strip()[:1000]
    if not question:
        return {'answer':'Please enter a KYC question. I can help with case status, queue summary, document issues, risk rules and next actions.'}
    answer=None
    if API_KEY and API_KEY.lower() not in ('your_gemini_api_key_here','paste_your_key_here'):
        try:
            from google import genai
            client=genai.Client(api_key=API_KEY)
            role='customer' if user.get('role')=='customer' else 'staff'
            facts = fallback_answer(user, question)
            ctx=(
                f"You are TrustShield KYC Assistant for a {role} user of an enterprise KYC platform. "
                "Be concise, professional and action-oriented (max 4 sentences). "
                "Do not expose other customers' data or staff-only portfolio details to customers. "
                "Use the following platform facts as ground truth and do not contradict them: "
                f"{facts}"
            )
            resp=client.models.generate_content(model=MODEL, contents=ctx+'\nQuestion: '+question)
            text=getattr(resp,'text',None)
            answer = text.strip() if text and text.strip() else None
        except Exception:
            answer=None
    return {'answer': answer or fallback_answer(user,question), 'mode': 'gemini' if answer else 'local'}

@app.get('/api/chat/health')
def chat_health(request: Request):
    user=get_user(request) or {'role':'guest'}
    return {'status':'ok','role':user.get('role'),'gemini_configured':bool(API_KEY),'model':MODEL}
