# TrustShield KYC FastAPI Enterprise v14 Complete Tested

AGENTS_002 - Agentic KYC Intelligence Platform.

Run:
```bash
python -m pip install -r requirements.txt
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8501
```

AMD Cloud URL: `/proxy/8501/`

Login:
- Staff: `staff / Trust@123`
- Customer: `cust001 / Trust@123`

Features:
- Enterprise staff command center
- KYC case workbench
- Customer 360 profile with evidence locker
- Full AI agent orchestration from customer profile
- Separate `ai_agents/` folder with orchestrator and individual agents
- Compliance, AML, sanctions, adverse media, fraud, risk, decision, human review and audit governance layers
- Customer portal with KYC status, checklist, upload, notifications and final decision
- Floating AI assistant with Gemini support and local fallback
