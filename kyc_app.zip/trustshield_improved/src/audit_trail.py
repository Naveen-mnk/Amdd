"""
Tamper-Evident Append-Only Audit Trail.

Improvements over plain JSON list:
  • Each event is hash-chained to the previous event (blockchain-style)
    — any modification or deletion breaks the chain and is detectable.
  • Append-only JSONL file (one JSON object per line) — no full-file rewrites,
    safe for concurrent writers, and avoids the "load whole file, overwrite" pattern.
  • verify_chain() can be called by compliance to prove the log hasn't been altered.
"""
from __future__ import annotations
import json
import hashlib
import threading
from datetime import datetime
from pathlib import Path
from src.config import DIRS

_AUDIT_FILE: Path = DIRS["audit_logs"] / "audit_trail.jsonl"
_GENESIS_HASH = "0" * 64
_lock = threading.Lock()


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _hash_event(event: dict, prev_hash: str) -> str:
    """SHA-256 hash of the event payload chained with the previous hash."""
    payload = json.dumps(event, sort_keys=True, default=str) + prev_hash
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _get_last_hash() -> str:
    if not _AUDIT_FILE.exists():
        return _GENESIS_HASH
    last_hash = _GENESIS_HASH
    try:
        with open(_AUDIT_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                last_hash = rec.get("event_hash", _GENESIS_HASH)
    except Exception:
        pass
    return last_hash


def append_event(
    event_type: str,
    actor: str,
    case_id: str,
    details: str,
    **extra,
) -> dict:
    """
    Appends a new tamper-evident event to the audit trail.
    Returns the full record written (including its hash).
    """
    with _lock:
        prev_hash = _get_last_hash()
        event = {
            "timestamp": _now(),
            "event_type": event_type,
            "actor": actor,
            "case_id": case_id,
            "details": details,
        }
        event.update(extra)
        event_hash = _hash_event(event, prev_hash)
        event["prev_hash"] = prev_hash
        event["event_hash"] = event_hash

        with open(_AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, default=str) + "\n")

        return event


def read_events(case_id: str | None = None, limit: int = 500) -> list[dict]:
    """Reads recent events, optionally filtered by case_id (most recent last)."""
    if not _AUDIT_FILE.exists():
        return []
    events = []
    try:
        with open(_AUDIT_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                if case_id is None or rec.get("case_id") == case_id:
                    events.append(rec)
    except Exception:
        return []
    return events[-limit:]


def verify_chain() -> dict:
    """
    Verifies the integrity of the entire audit chain.
    Returns {"valid": bool, "total_events": int, "first_invalid_index": int|None}
    """
    if not _AUDIT_FILE.exists():
        return {"valid": True, "total_events": 0, "first_invalid_index": None}

    prev_hash = _GENESIS_HASH
    idx = 0
    try:
        with open(_AUDIT_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                stored_hash = rec.get("event_hash")
                stored_prev = rec.get("prev_hash")
                if stored_prev != prev_hash:
                    return {"valid": False, "total_events": idx, "first_invalid_index": idx}

                check_event = {k: v for k, v in rec.items() if k not in ("event_hash", "prev_hash")}
                recomputed = _hash_event(check_event, stored_prev)
                if recomputed != stored_hash:
                    return {"valid": False, "total_events": idx, "first_invalid_index": idx}

                prev_hash = stored_hash
                idx += 1
    except Exception as e:
        return {"valid": False, "total_events": idx, "first_invalid_index": idx, "error": str(e)}

    return {"valid": True, "total_events": idx, "first_invalid_index": None}


def migrate_legacy_json():
    """One-time migration: converts old audit_trail.json list into the new hash-chained JSONL."""
    legacy_path = DIRS["audit_logs"] / "audit_trail.json"
    if not legacy_path.exists() or _AUDIT_FILE.exists():
        return
    try:
        with open(legacy_path, "r", encoding="utf-8") as f:
            old_events = json.load(f)
        for rec in old_events:
            append_event(
                event_type=rec.get("action", "Legacy Event"),
                actor=rec.get("actor", "Unknown"),
                case_id=rec.get("case_id", ""),
                details=json.dumps({k: v for k, v in rec.items() if k not in ("action", "actor", "case_id")}, default=str),
            )
    except Exception:
        pass


migrate_legacy_json()
