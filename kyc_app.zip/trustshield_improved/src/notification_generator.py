"""
Notification & Email Draft Generator — world-class structured drafts.
Improvements:
  • Consistent tone-of-voice (professional banking language)
  • All drafts include case ref, timestamp, and next-action instructions
  • Staff drafts include risk score, drivers summary, and SLA reminder
  • Templates broken into named sections for easy customisation
  • Added: re_upload, escalation_compliance, escalation_fraud, auto_approved drafts
"""
from __future__ import annotations
from datetime import datetime


def _now() -> str:
    return datetime.now().strftime("%d %b %Y, %I:%M %p IST")


def _risk_summary(risk_res: dict) -> str:
    score = risk_res.get("risk_score", 0)
    level = risk_res.get("risk_level", "Unknown")
    decision = risk_res.get("recommended_decision", "")
    return f"Risk Score: {score}/100 ({level}) | Recommendation: {decision}"


def _driver_list(risk_res: dict, max_drivers: int = 5) -> str:
    drivers = risk_res.get("risk_drivers", [])[:max_drivers]
    if not drivers:
        return "  • No significant risk drivers identified."
    return "\n".join(f"  • {d}" for d in drivers)


# ── CUSTOMER-FACING DRAFTS ─────────────────────────────────────────

def draft_customer_approval(case_id: str, customer_name: str) -> dict:
    subject = f"KYC Application Approved — {case_id}"
    body = f"""Dear {customer_name},

Congratulations! We are delighted to inform you that your Know Your Customer (KYC) 
verification has been successfully completed.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Reference: {case_id}
  Status:    ✅ APPROVED
  Date:      {_now()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your identity and documents have been verified and your account is now fully activated.

If you have any queries, please contact our support team quoting your Case ID: {case_id}.

Warm regards,
TrustShield AI — KYC Operations
"""
    return {"subject": subject, "body": body}


def draft_customer_rejection(case_id: str, customer_name: str, reason: str) -> dict:
    subject = f"KYC Application Status Update — {case_id}"
    body = f"""Dear {customer_name},

Thank you for submitting your KYC application. After careful review by our compliance 
team, we regret to inform you that we are unable to complete your KYC verification 
at this time.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Reference:  {case_id}
  Status:     ❌ ACTION REQUIRED / NOT APPROVED
  Date:       {_now()}
  Reason:     {reason}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

If you believe this decision was made in error, or if you would like to provide 
additional documentation, please contact our compliance support team and quote 
your Case ID: {case_id}.

Please be assured that all your personal data is handled as per our Privacy Policy 
and applicable data protection regulations.

Regards,
TrustShield AI — Compliance Operations
"""
    return {"subject": subject, "body": body}


def draft_customer_manual_review(case_id: str, customer_name: str) -> dict:
    subject = f"KYC Application — Under Review — {case_id}"
    body = f"""Dear {customer_name},

Thank you for your patience. Your KYC application is currently undergoing enhanced 
verification by our compliance team.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Reference: {case_id}
  Status:    🔍 UNDER MANUAL REVIEW
  Date:      {_now()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

No action is required from you at this time. Our team will reach out if any 
additional information is needed.

Expected resolution: within 3–5 working days.

Regards,
TrustShield AI — KYC Operations
"""
    return {"subject": subject, "body": body}


def draft_customer_reupload(case_id: str, customer_name: str, missing_docs: list[str]) -> dict:
    doc_list = "\n".join(f"  • {d}" for d in missing_docs) if missing_docs else "  • One or more mandatory documents"
    subject = f"Action Required: Re-upload Documents — {case_id}"
    body = f"""Dear {customer_name},

We have reviewed your KYC submission and require the following updated or corrected 
documents to proceed:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Reference: {case_id}
  Status:    📎 DOCUMENTS REQUIRED
  Date:      {_now()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Required Documents:
{doc_list}

Please log in to the Customer Portal and navigate to "Upload Document" to submit 
the above. Ensure documents are clear, unobstructed, and unexpired.

Deadline: Please upload within 7 working days to avoid case closure.

Regards,
TrustShield AI — Document Verification Team
"""
    return {"subject": subject, "body": body}


def draft_customer_under_enhanced_review(case_id: str, customer_name: str) -> dict:
    subject = f"KYC Application — Enhanced Due Diligence — {case_id}"
    body = f"""Dear {customer_name},

Your KYC application is currently subject to Enhanced Due Diligence (EDD) as 
required by our compliance policy.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Reference: {case_id}
  Status:    ⚠️  ENHANCED REVIEW
  Date:      {_now()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This is a standard process and does not imply any wrongdoing. A compliance officer 
will contact you if additional documentation or clarification is required.

Regards,
TrustShield AI — Compliance Operations
"""
    return {"subject": subject, "body": body}


# ── STAFF-FACING DRAFTS ───────────────────────────────────────────

def draft_staff_review_alert(case_id: str, customer_id: str, risk_res: dict, guardrail_res: dict) -> dict:
    blocked = guardrail_res.get("blocked_reasons", [])
    warnings_list = guardrail_res.get("warning_reasons", [])
    subject = f"[TrustShield Alert] KYC Case Requires Review — {case_id}"
    body = f"""KYC REVIEW ALERT — INTERNAL STAFF NOTIFICATION

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Case ID:     {case_id}
  Customer ID: {customer_id}
  Generated:   {_now()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RISK ASSESSMENT
  {_risk_summary(risk_res)}

KEY RISK DRIVERS
{_driver_list(risk_res)}

GUARDRAIL STATUS: {guardrail_res.get("status", "Unknown")}
  Policy Reference: {guardrail_res.get("policy_reference", "")}
  Required Action:  {guardrail_res.get("required_human_action", "")}

{"BLOCKED REASONS:" + chr(10) + chr(10).join(f"  ✗ {r}" for r in blocked) if blocked else ""}
{"WARNINGS:" + chr(10) + chr(10).join(f"  ⚠ {w}" for w in warnings_list) if warnings_list else ""}

NEXT STEP: Log in to TrustShield AI Staff Portal → KYC Case Queue → {case_id}
  to review evidence, agent findings, and take required action.

--- INTERNAL CONFIDENTIAL — DO NOT FORWARD ---
"""
    return {"subject": subject, "body": body}


def draft_staff_escalation_compliance(case_id: str, customer_id: str, risk_res: dict) -> dict:
    subject = f"[ESCALATION] Compliance Review Required — {case_id}"
    body = f"""COMPLIANCE ESCALATION — ACTION REQUIRED

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Case ID:        {case_id}
  Customer ID:    {customer_id}
  Escalated On:   {_now()}
  Risk Score:     {risk_res.get("risk_score", 0)}/100 ({risk_res.get("risk_level", "")})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This case has been automatically escalated to the Compliance team due to one or more 
compliance guardrail triggers.

RISK DRIVERS:
{_driver_list(risk_res, max_drivers=8)}

REQUIRED: Compliance Officer to review within 24 hours and take one of the following 
actions: Approve with Override, Reject, or Escalate to MLRO.

--- INTERNAL CONFIDENTIAL ---
"""
    return {"subject": subject, "body": body}


def draft_staff_escalation_fraud(case_id: str, customer_id: str, risk_res: dict) -> dict:
    subject = f"[FRAUD ALERT] Suspected Fraud — Immediate Review — {case_id}"
    body = f"""FRAUD INTELLIGENCE ALERT — IMMEDIATE ATTENTION REQUIRED

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Case ID:        {case_id}
  Customer ID:    {customer_id}
  Flagged On:     {_now()}
  Risk Level:     {risk_res.get("risk_level", "HIGH")} ({risk_res.get("risk_score", 0)}/100)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The AI fraud intelligence agents have detected fraud signals for the above customer.

FRAUD SIGNALS:
{_driver_list(risk_res, max_drivers=10)}

REQUIRED: Fraud Analyst to investigate and file STR (Suspicious Transaction Report) 
if warranted under PMLA 2002. Do not approve this application until cleared.

--- INTERNAL CONFIDENTIAL — RESTRICTED ACCESS ---
"""
    return {"subject": subject, "body": body}


def draft_staff_auto_approved(case_id: str, customer_id: str) -> dict:
    subject = f"[Auto Approved] Clean KYC Case — {case_id}"
    body = f"""KYC AUTO-APPROVAL NOTIFICATION

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Case ID:     {case_id}
  Customer ID: {customer_id}
  Approved On: {_now()}
  Status:      ✅ AUTO APPROVED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TrustShield AI completed full verification. No discrepancies detected. 
The case has been automatically approved and is now in the Approved queue.

Staff can still override via Case Queue → Manual Status Change if required.

--- INTERNAL NOTIFICATION ---
"""
    return {"subject": subject, "body": body}


# ── MASTER GENERATOR ─────────────────────────────────────────────

def generate_all_notification_drafts(
    case_details: dict,
    risk_res: dict,
    guardrail_res: dict,
    gemini_reasoning: str,
    decision_workflow: dict,
) -> dict:
    cust = case_details.get("customer", {})
    case_id = cust.get("case_id", "CASE00000")
    customer_id = cust.get("customer_id", "CUST00000")
    full_name = cust.get("full_name", "Valued Customer").split()[0]
    final_status = decision_workflow.get("final_case_status", "")
    system_action = decision_workflow.get("system_action", "")

    drafts: dict[str, dict] = {}

    # Always generate the staff review alert
    drafts["staff_review_alert"] = draft_staff_review_alert(case_id, customer_id, risk_res, guardrail_res)

    # Customer draft based on workflow outcome
    if system_action == "Auto Approved":
        drafts["customer_approval"] = draft_customer_approval(case_id, full_name)
        drafts["staff_auto_approved"] = draft_staff_auto_approved(case_id, customer_id)
    elif "Reject" in system_action or final_status == "Rejected":
        reason = decision_workflow.get("decision_reason", "Compliance policy requirements not met.")
        drafts["customer_rejection"] = draft_customer_rejection(case_id, full_name, reason)
        drafts["staff_escalation_compliance"] = draft_staff_escalation_compliance(case_id, customer_id, risk_res)
    elif "Re-upload" in system_action or "Documents Required" in final_status:
        missing = [
            d.get("document_type", "Document")
            for d in case_details.get("documents", [])
            if str(d.get("document_status", "")).lower() in ("missing", "failed", "invalid", "rejected")
        ]
        drafts["customer_reupload_request"] = draft_customer_reupload(case_id, full_name, missing)
    elif "Manager" in final_status or guardrail_res.get("status") == "Blocked":
        drafts["customer_enhanced_review"] = draft_customer_under_enhanced_review(case_id, full_name)
        drafts["staff_escalation_compliance"] = draft_staff_escalation_compliance(case_id, customer_id, risk_res)
        if any("fraud" in r.lower() or "synthetic" in r.lower() or "duplicate" in r.lower()
               for r in guardrail_res.get("blocked_reasons", [])):
            drafts["staff_escalation_fraud"] = draft_staff_escalation_fraud(case_id, customer_id, risk_res)
    else:
        drafts["customer_manual_review"] = draft_customer_manual_review(case_id, full_name)

    return drafts
