import os
import json
import pandas as pd
from pathlib import Path
from src.config import FILES, DIRS
from src.data_generator import generate_all_datasets
import src.cache as cache
import src.audit_trail as audit_trail

# ─────────────────────────────────────────────────────────────────
#  DATA BOOTSTRAP
# ─────────────────────────────────────────────────────────────────
def initialize_data_if_missing():
    """Checks if any dataset files are missing. If so, triggers the generator."""
    missing = False
    for name, path in FILES.items():
        if not path.exists():
            missing = True
            break
    test_img = DIRS["uploads"] / "CUST00001" / "customer_photo.png"
    if not test_img.exists():
        missing = True
    if missing:
        generate_all_datasets()

initialize_data_if_missing()

# ─────────────────────────────────────────────────────────────────
#  CACHED READERS
# ─────────────────────────────────────────────────────────────────
def load_customers() -> pd.DataFrame:
    cached = cache.get("customers")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["customers"])
    cache.set("customers", df, ttl=30)
    return df

def save_customers(df: pd.DataFrame):
    df.to_csv(FILES["customers"], index=False)
    cache.invalidate("customers")
    cache.invalidate_prefix("case_details:")

def load_kyc_documents() -> pd.DataFrame:
    cached = cache.get("kyc_documents")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["kyc_documents"])
    cache.set("kyc_documents", df, ttl=30)
    return df

def save_kyc_documents(df: pd.DataFrame):
    df.to_csv(FILES["kyc_documents"], index=False)
    cache.invalidate("kyc_documents")
    cache.invalidate_prefix("case_details:")

def load_transactions() -> pd.DataFrame:
    cached = cache.get("transactions")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["transactions"])
    cache.set("transactions", df, ttl=120)
    return df

def load_fraud_watchlist() -> pd.DataFrame:
    cached = cache.get("fraud_watchlist")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["fraud_watchlist"])
    cache.set("fraud_watchlist", df, ttl=120)
    return df

def load_sanctions_watchlist() -> pd.DataFrame:
    cached = cache.get("sanctions_watchlist")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["sanctions_watchlist"])
    cache.set("sanctions_watchlist", df, ttl=120)
    return df

def load_pep_watchlist() -> pd.DataFrame:
    cached = cache.get("pep_watchlist")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["pep_watchlist"])
    cache.set("pep_watchlist", df, ttl=120)
    return df

def load_adverse_media() -> pd.DataFrame:
    cached = cache.get("adverse_media")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["adverse_media"])
    cache.set("adverse_media", df, ttl=120)
    return df

def load_case_history() -> pd.DataFrame:
    return pd.read_csv(FILES["case_history"])

def save_case_history(df: pd.DataFrame):
    df.to_csv(FILES["case_history"], index=False)

def load_selfie_verification() -> pd.DataFrame:
    cached = cache.get("selfie_verification")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["selfie_verification"])
    cache.set("selfie_verification", df, ttl=30)
    return df

def save_selfie_verification(df: pd.DataFrame):
    df.to_csv(FILES["selfie_verification"], index=False)
    cache.invalidate("selfie_verification")
    cache.invalidate_prefix("case_details:")

def load_document_file_registry() -> pd.DataFrame:
    cached = cache.get("document_file_registry")
    if cached is not None:
        return cached
    df = pd.read_csv(FILES["document_file_registry"])
    cache.set("document_file_registry", df, ttl=60)
    return df

def save_document_file_registry(df: pd.DataFrame):
    df.to_csv(FILES["document_file_registry"], index=False)
    cache.invalidate("document_file_registry")

def load_compliance_rules() -> dict:
    cached = cache.get("compliance_rules")
    if cached is not None:
        return cached
    with open(FILES["compliance_rules"], "r") as f:
        rules = json.load(f)
    cache.set("compliance_rules", rules, ttl=300)
    return rules

def load_kyc_policy() -> str:
    cached = cache.get("kyc_policy")
    if cached is not None:
        return cached
    with open(FILES["kyc_policy_knowledge"], "r") as f:
        text = f.read()
    cache.set("kyc_policy", text, ttl=300)
    return text

# ─────────────────────────────────────────────────────────────────
#  CASE AGGREGATION  (cached per case_id)
# ─────────────────────────────────────────────────────────────────
def get_case_details(case_id: str) -> dict:
    """Retrieves all aggregated data fields for a particular case (cached)."""
    ck = f"case_details:{case_id}"
    cached = cache.get(ck)
    if cached is not None:
        return cached

    df_c = load_customers()
    row_c = df_c[df_c["case_id"] == case_id]
    if row_c.empty:
        return {}
    cust = row_c.iloc[0].to_dict()
    cust_id = cust["customer_id"]

    df_d = load_kyc_documents()
    docs = df_d[df_d["case_id"] == case_id].to_dict(orient="records")

    df_t = load_transactions()
    txns = df_t[df_t["case_id"] == case_id].to_dict(orient="records")

    df_f = load_fraud_watchlist()
    _filt = df_f[df_f["case_id"] == case_id]
    fraud = _filt.iloc[0].to_dict() if not _filt.empty else {}

    df_s = load_sanctions_watchlist()
    _filt = df_s[df_s["case_id"] == case_id]
    sanctions = _filt.iloc[0].to_dict() if not _filt.empty else {}

    df_p = load_pep_watchlist()
    _filt = df_p[df_p["case_id"] == case_id]
    pep = _filt.iloc[0].to_dict() if not _filt.empty else {}

    df_a = load_adverse_media()
    _filt = df_a[df_a["case_id"] == case_id]
    adverse = _filt.iloc[0].to_dict() if not _filt.empty else {}

    df_selfie = load_selfie_verification()
    _filt = df_selfie[df_selfie["case_id"] == case_id]
    selfie = _filt.iloc[0].to_dict() if not _filt.empty else {}

    df_reg = load_document_file_registry()
    registry = df_reg[df_reg["case_id"] == case_id].to_dict(orient="records")

    df_hist = load_case_history()
    history = df_hist[df_hist["case_id"] == case_id].to_dict(orient="records")

    result = {
        "customer": cust,
        "documents": docs,
        "transactions": txns,
        "fraud_watchlist": fraud,
        "sanctions_watchlist": sanctions,
        "pep_watchlist": pep,
        "adverse_media": adverse,
        "selfie_verification": selfie,
        "document_file_registry": registry,
        "case_history": history,
    }
    cache.set(ck, result, ttl=30)
    return result

# ─────────────────────────────────────────────────────────────────
#  STATUS UPDATE  (invalidates caches)
# ─────────────────────────────────────────────────────────────────
def update_case_status(case_id: str, new_status: str, action_by: str, comments: str) -> bool:
    df_c = load_customers()
    if case_id not in df_c["case_id"].values:
        return False

    df_c.loc[df_c["case_id"] == case_id, "case_status"] = new_status
    save_customers(df_c)

    df_hist = load_case_history()
    row = df_c[df_c["case_id"] == case_id].iloc[0]
    new_event = {
        "case_id": case_id,
        "customer_id": row["customer_id"],
        "created_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
        "current_status": new_status,
        "assigned_queue": row["assigned_queue"],
        "sla_hours": int(row["sla_hours"]),
        "escalation_level": 2 if "Escalated" in new_status else 1 if new_status == "Manual Review Required" else 0,
        "last_action": f"{action_by}: {comments}",
    }
    df_hist = pd.concat([df_hist, pd.DataFrame([new_event])], ignore_index=True)
    save_case_history(df_hist)

    audit_trail.append_event(
        event_type="Case Status Update",
        actor=action_by,
        case_id=case_id,
        details=f"Status changed to '{new_status}'. Comments: {comments}",
        customer_id=str(row["customer_id"]),
        new_status=new_status,
    )

    # Invalidate per-case cache so next read reflects new status
    cache.invalidate(f"case_details:{case_id}")
    return True
