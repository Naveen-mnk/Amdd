"""
Error UX Helpers — converts raw exceptions into friendly, actionable messages
for display in the Streamlit UI, while preserving full details for logs.
"""
from __future__ import annotations
import logging
import traceback
from contextlib import contextmanager

logger = logging.getLogger(__name__)

# Map of (substring in exception message) -> friendly message
_FRIENDLY_MAP = [
    ("FileNotFoundError", "A required data file is missing. Please contact support — our team has been notified."),
    ("PermissionError", "We don't have permission to access a required resource. Please contact support."),
    ("JSONDecodeError", "Some stored data appears corrupted. Please contact support to restore it."),
    ("ConnectionError", "We couldn't reach an external service. Please check your connection and try again."),
    ("Timeout", "The request took too long to respond. Please try again in a moment."),
    ("KeyError", "Some expected information was missing from this record. Please contact support."),
    ("ValueError", "Some of the information provided was in an unexpected format."),
    ("EmptyDataError", "No data was found for this request."),
]


def friendly_message(exc: Exception, fallback: str = "Something went wrong. Please try again, or contact support if the issue persists.") -> str:
    """Returns a user-safe message for the given exception."""
    exc_name = type(exc).__name__
    exc_str = str(exc)
    for key, msg in _FRIENDLY_MAP:
        if key in exc_name or key in exc_str:
            return msg
    return fallback


@contextmanager
def safe_section(section_name: str, st_module=None):
    """
    Context manager for wrapping a UI section. On exception:
      - logs the full traceback
      - shows a friendly st.error() message (if st_module provided)
      - does NOT re-raise, so the rest of the page keeps rendering
    Usage:
        with safe_section("Customer Profile", st):
            ... risky rendering code ...
    """
    try:
        yield
    except Exception as e:
        logger.exception("Error in section '%s': %s", section_name, e)
        msg = friendly_message(e)
        if st_module is not None:
            st_module.error(f"⚠️ {section_name}: {msg}")
            with st_module.expander("Technical details (for support)", expanded=False):
                st_module.code(traceback.format_exc())
        # swallow — don't crash the whole page


def log_and_get_message(e: Exception, context: str = "") -> str:
    """Logs full traceback and returns a friendly message string."""
    logger.exception("Error%s: %s", f" in {context}" if context else "", e)
    return friendly_message(e)
