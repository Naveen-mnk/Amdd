"""
Guardrails Policy Engine — evaluates hard compliance rules.
Improvements:
  • Structured severity levels (CRITICAL / HIGH / MEDIUM)
  • Separated blocked_reasons (hard stop) vs warning_reasons (soft flag)
  • Policy reference linked to specific rule key
  • Returns human-friendly required_human_action per severity
"""
from __future__ import annotations
from typing import Any


def _safe_float(val: Any, default: float = 0.0) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def validate_guardrails(case_details: dict, risk_result: dict, rules: dict) -> dict:
    """
    Applies compliance guardrails.
    Returns: status, blocked_reasons, warning_reasons, policy_reference, required_human_action
    """
    blocked: list[str] = []
    warnings: list[str] = []

    # ── CRITICAL / HARD BLOCKS ───────────────────────────────────────
    sanctions = case_details.get("sanctions_watchlist", {}) or {}
    if sanctions.get("sanctions_match", 0):
        blocked.append("Sanctions / AML watchlist match — onboarding prohibited by RBI/PMLA guidelines")

    fraud = case_details.get("fraud_watchlist", {}) or {}
    if fraud.get("duplicate_pan", 0):
        blocked.append("Duplicate PAN — same PAN linked to another active/fraud account")
    if fraud.get("synthetic_identity_signal", 0):
        blocked.append("Synthetic identity signal — structured fraud indicator")

    selfie = case_details.get("selfie_verification", {}) or {}
    if selfie.get("liveness_check") == "Failed":
        blocked.append("Liveness check failed — anti-spoofing policy violation")

    try:
        match_score = _safe_float(selfie.get("selfie_match_score", 1.0))
        if match_score < 0.50:
            blocked.append(f"Face match failed ({match_score*100:.0f}%) — identity cannot be confirmed")
    except Exception:
        pass

    for doc in case_details.get("documents", []):
        tamper = str(doc.get("tampering_indicator", "")).lower()
        if tamper not in ("not detected", "none", "0", "false", "nan", ""):
            blocked.append(f"Document tampering detected on {doc.get('document_type', 'document')} — policy hard stop")
            break

    risk_score = risk_result.get("risk_score", 0)
    if risk_score >= rules.get("reject_score", 80):
        blocked.append(f"Risk score {risk_score}/100 exceeds reject threshold — mandatory senior review")

    # ── HIGH / SOFT BLOCKS (manual review triggers) ──────────────────
    pep = case_details.get("pep_watchlist", {}) or {}
    if pep.get("pep_match", 0):
        warnings.append(f"PEP match ({pep.get('pep_category','Category-1')}) — enhanced due diligence required")

    adverse = case_details.get("adverse_media", {}) or {}
    if adverse.get("adverse_media_match", 0):
        warnings.append("Adverse media match — regulatory scrutiny; compliance officer review needed")

    if fraud.get("repeated_kyc_attempt", 0):
        warnings.append("Repeated KYC attempts — potential fraud probe recommended")
    if fraud.get("duplicate_mobile", 0):
        warnings.append("Duplicate mobile number — linked to another account")

    if risk_score >= rules.get("escalate_score", 60):
        warnings.append(f"Risk score {risk_score}/100 in escalation band — compliance review mandatory")

    # ── DETERMINE OVERALL STATUS ─────────────────────────────────────
    if blocked:
        status = "Blocked"
        policy_ref = "RBI KYC Master Directions 2016 (Updated 2023) — Section 38 / PMLA 2002"
        action = "STOP — Do not proceed. Escalate to Compliance Manager and MLRO immediately."
    elif warnings:
        status = "Warning"
        policy_ref = "RBI KYC Master Directions — EDD Clause / FATF Recommendation 12 (PEP)"
        action = "Route to Compliance Officer for Enhanced Due Diligence before approval."
    else:
        status = "Allowed"
        policy_ref = "Standard KYC Policy — CDD requirements satisfied"
        action = "Proceed with standard onboarding workflow."

    return {
        "status": status,
        "blocked_reasons": blocked,
        "warning_reasons": warnings,
        "policy_reference": policy_ref,
        "required_human_action": action,
    }
