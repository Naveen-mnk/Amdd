Demo KYC documents for CUST009 - Mohit Jain
Gender: Male
DOB: 02-02-1990
Address: 101, Vijay Nagar, Indore - 452010

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
