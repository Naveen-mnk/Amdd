Demo KYC documents for CUST003 - Amit Kumar
Gender: Male
DOB: 03-03-1992
Address: 12/56, Swaroop Nagar, Kanpur - 208002

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
