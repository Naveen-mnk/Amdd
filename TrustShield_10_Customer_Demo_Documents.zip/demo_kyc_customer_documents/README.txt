Synthetic KYC Demo Document Dataset

Contains 10 customer folders with male/female demo customers.
Each customer folder includes photo + PAN/Tax ID + Aadhaar/National ID + Passport + Driving License + Voter ID + Address Proof + Bank Statement + Income Proof.
For each customer, the address is kept the same across all proof documents for matching validation.

Important: All files are synthetic demo documents with visible SAMPLE/DEMO watermarks. Not valid for official or legal use.
