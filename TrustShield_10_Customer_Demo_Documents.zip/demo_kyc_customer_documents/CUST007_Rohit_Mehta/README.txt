Demo KYC documents for CUST007 - Rohit Mehta
Gender: Male
DOB: 12-12-1991
Address: E-78, Malviya Nagar, Jaipur - 302017

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
