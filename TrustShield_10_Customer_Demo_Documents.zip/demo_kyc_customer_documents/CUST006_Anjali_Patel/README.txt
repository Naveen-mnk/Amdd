Demo KYC documents for CUST006 - Anjali Patel
Gender: Female
DOB: 08-09-1995
Address: A/2, Silver Heights, Satellite, Ahmedabad - 380015

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
