Demo KYC documents for CUST008 - Neha Reddy
Gender: Female
DOB: 27-04-1996
Address: Plot No. 45, Hitech City, Hyderabad - 500081

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
