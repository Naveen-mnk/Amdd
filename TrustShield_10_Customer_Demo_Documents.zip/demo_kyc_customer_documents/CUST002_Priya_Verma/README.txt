Demo KYC documents for CUST002 - Priya Verma
Gender: Female
DOB: 21-03-1996
Address: A-501, Shanti Heights, Andheri West, Mumbai - 400058

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
