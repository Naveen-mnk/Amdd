Demo KYC documents for CUST005 - Vikram Singh
Gender: Male
DOB: 19-06-1993
Address: 89, BBD Green City, Lucknow - 226010

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
