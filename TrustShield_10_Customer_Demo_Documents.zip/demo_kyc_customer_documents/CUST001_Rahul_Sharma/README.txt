Demo KYC documents for CUST001 - Rahul Sharma
Gender: Male
DOB: 14-08-1992
Address: 24 Lake View Road, Chennai - 600041

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
