Demo KYC documents for CUST004 - Sneha Iyer
Gender: Female
DOB: 21-11-1994
Address: No. 34, 5th Cross, Indiranagar, Bengaluru - 560038

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
