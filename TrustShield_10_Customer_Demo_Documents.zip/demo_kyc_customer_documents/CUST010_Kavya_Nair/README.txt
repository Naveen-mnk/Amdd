Demo KYC documents for CUST010 - Kavya Nair
Gender: Female
DOB: 15-01-1997
Address: Door No. 11/22, Marine Drive, Kochi - 682011

All documents for this customer intentionally use the same address for validation testing.
These are synthetic DEMO documents only, not valid for official or legal use.
