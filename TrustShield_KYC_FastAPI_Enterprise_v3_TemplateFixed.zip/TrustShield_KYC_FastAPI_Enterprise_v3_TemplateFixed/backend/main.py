
import os, json, shutil, re
from pathlib import Path
from datetime import datetime
from typing import Optional
import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Form, UploadFile, File, Depends
from fastapi.responses import RedirectResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE/'.env')
APP_SECRET = os.getenv('APP_SECRET_KEY','trustshield-secret')
MODEL = os.getenv('GEMINI_MODEL','gemini-3.5-flash')
API_KEY = os.getenv('GOOGLE_API_KEY','')

app = FastAPI(title='TrustShield KYC Enterprise Platform')
app.add_middleware(SessionMiddleware, secret_key=APP_SECRET)
app.mount('/static', StaticFiles(directory=BASE/'frontend'/'static'), name='static')
app.mount('/uploads', StaticFiles(directory=BASE/'uploads'), name='uploads')
templates = Jinja2Templates(directory=str(BASE/'frontend'/'templates'))

def read_csv(name):
    p = BASE/'data'/name
    return pd.read_csv(p) if p.exists() else pd.DataFrame()

def load_data():
    return {
        'customers': read_csv('customers.csv'),
        'docs': read_csv('kyc_documents.csv'),
        'files': read_csv('document_file_registry.csv'),
        'history': read_csv('case_history.csv'),
        'selfie': read_csv('selfie_verification.csv'),
        'txns': read_csv('transactions.csv'),
        'sanctions': read_csv('sanctions_watchlist.csv'),
        'pep': read_csv('pep_watchlist.csv'),
        'fraud': read_csv('fraud_watchlist.csv'),
        'adverse': read_csv('adverse_media.csv'),
    }

def normalize_status(s):
    s=str(s)
    if 'Approved' in s: return 'Approved'
    if 'Reject' in s: return 'Rejected'
    if 'Document' in s or 'Re-upload' in s: return 'More Documents Required'
    if 'Review' in s or 'Pending' in s: return 'Manual Review Required'
    return s

def status_badge(status):
    st=normalize_status(status)
    if st=='Approved': return 'b-approved'
    if st=='Rejected': return 'b-reject'
    if 'Document' in st: return 'b-pending'
    if 'Review' in st or 'Pending' in st: return 'b-review'
    return 'b-neutral'

def get_user(request: Request):
    return request.session.get('user')

def require_login(request: Request):
    user=get_user(request)
    if not user:
        return None
    return user

def role_home(role):
    return '/staff/dashboard' if role=='staff' else '/customer/dashboard'

def get_customer(identifier):
    d=load_data(); c=d['customers']
    if c.empty: return None
    q=str(identifier).strip().lower()
    m=c[(c['case_id'].astype(str).str.lower()==q)|(c['customer_id'].astype(str).str.lower()==q)|(c['login_username'].astype(str).str.lower()==q)]
    return None if m.empty else m.iloc[0].to_dict()

def customer_context(identifier):
    d=load_data(); cust=get_customer(identifier)
    if not cust: return None
    cid=cust['customer_id']; case=cust['case_id']
    docs=d['docs'][d['docs']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['docs'].empty else []
    files=d['files'][d['files']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['files'].empty else []
    hist=d['history'][d['history']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['history'].empty else []
    selfie=d['selfie'][d['selfie']['customer_id'].astype(str)==str(cid)].to_dict('records') if not d['selfie'].empty else []
    issues=[]
    for doc in docs:
        if str(doc.get('document_status','')).lower()!='passed': issues.append(f"{doc.get('document_type')}: {doc.get('document_status')}")
        if str(doc.get('quality_status','')).lower()!='passed': issues.append(f"{doc.get('document_type')}: quality {doc.get('quality_status')}")
        if str(doc.get('tampering_indicator','')).lower()!='not detected': issues.append(f"{doc.get('document_type')}: tampering indicator {doc.get('tampering_indicator')}")
    discrepancy=len(issues)
    decision = normalize_status(cust.get('case_status',''))
    return {'cust':cust,'docs':docs,'files':files,'hist':hist,'selfie':selfie,'issues':issues,'discrepancy':discrepancy,'decision':decision}

def queue_df(status=None):
    c=load_data()['customers'].copy()
    if c.empty: return c
    c['normalized_status']=c['case_status'].apply(normalize_status)
    if status and status!='All': c=c[c['normalized_status']==status]
    return c

def metrics():
    c=queue_df()
    if c.empty: return {}
    return {
        'total': len(c),
        'approved': int((c['normalized_status']=='Approved').sum()),
        'review': int((c['normalized_status']=='Manual Review Required').sum()),
        'docs': int((c['normalized_status']=='More Documents Required').sum()),
        'rejected': int((c['normalized_status']=='Rejected').sum()),
        'high': int(c['synthetic_risk_profile'].astype(str).str.contains('High|Critical',case=False,na=False).sum()) if 'synthetic_risk_profile' in c else 0,
    }

templates.env.filters['badge'] = status_badge


# Compatibility routes for notebook/proxy tools that still check Streamlit-style endpoints.
# This app is FastAPI, so these endpoints are not used by the UI, but returning 200 avoids confusing 404 logs.
@app.get('/_stcore/health')
def streamlit_health_compat():
    return {'status': 'ok', 'app': 'TrustShield FastAPI'}

@app.get('/_stcore/host-config')
def streamlit_host_config_compat():
    return {'server': 'fastapi', 'websocketCompression': False}

@app.get('/')
def root(request: Request):
    user=get_user(request)
    if user: return RedirectResponse(role_home(user['role']),303)
    return templates.TemplateResponse(request, 'login.html', {'request':request})

@app.post('/login')
def login(request: Request, username: str=Form(...), password: str=Form(...)):
    u=username.strip(); p=password.strip()
    if p!='Trust@123':
        return templates.TemplateResponse(request, 'login.html', {'request':request,'error':'Invalid username or password.'})
    if u.lower()=='staff':
        request.session['user']={'role':'staff','username':'staff','name':'KYC Operations Staff'}
        return RedirectResponse('/staff/dashboard',303)
    cust=get_customer(u)
    if cust:
        request.session['user']={'role':'customer','username':cust['login_username'],'customer_id':cust['customer_id'],'case_id':cust['case_id'],'name':cust['full_name']}
        return RedirectResponse('/customer/dashboard',303)
    return templates.TemplateResponse(request, 'login.html', {'request':request,'error':'Invalid username or password.'})

@app.get('/logout')
def logout(request: Request):
    request.session.clear(); return RedirectResponse('/',303)

@app.get('/staff/dashboard')
def staff_dashboard(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    d=load_data(); recent=queue_df().head(8).to_dict('records')
    return templates.TemplateResponse(request, 'staff_dashboard.html', {'request':request,'user':user,'active':'dashboard','m':metrics(),'recent':recent})

@app.get('/staff/queue')
def staff_queue(request: Request, status: str='All', q: str=''):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    df=queue_df(status)
    if q:
        ql=q.lower(); df=df[df.apply(lambda r: ql in ' '.join(map(str,r.values)).lower(), axis=1)]
    rows=df.head(200).to_dict('records')
    return templates.TemplateResponse(request, 'case_queue.html', {'request':request,'user':user,'active':'queue','rows':rows,'status':status,'q':q,'m':metrics()})

@app.get('/staff/case/{case_id}')
def case_profile(request: Request, case_id: str):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id)
    if not ctx: return templates.TemplateResponse(request, 'message.html', {'request':request,'user':user,'title':'Case not found','message':'The selected case was not found.'})
    return templates.TemplateResponse(request, 'case_profile.html', {'request':request,'user':user,'active':'profile',**ctx})

@app.post('/staff/case/{case_id}/action')
def case_action(request: Request, case_id: str, action: str=Form(...), note: str=Form('')):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    p=BASE/'outputs'/'audit_logs'/'staff_actions.log'
    with p.open('a', encoding='utf-8') as f: f.write(f"{datetime.now().isoformat()} | {user['username']} | {case_id} | {action} | {note}\n")
    return RedirectResponse(f'/staff/case/{case_id}?saved=1',303)

@app.get('/staff/agent-review')
def agent_review(request: Request, case_id: str='CASE001'):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    ctx=customer_context(case_id) or customer_context('CASE001')
    agents=[('Document Intelligence Agent','Extracted name, DOB, address and ID number from submitted documents','Completed'),('Identity Verification Agent','Compared selfie/photo with document photo and liveness status','Completed'),('Compliance Screening Agent','Checked sanctions, PEP and adverse media datasets','Completed'),('Fraud Intelligence Agent','Evaluated tampering, duplicate ID and suspicious behavior signals','Completed'),('Risk Intelligence Agent','Calculated explainable risk score and recommended queue','Completed'),('Human Review Agent','Routes exceptions for maker-checker review','Ready')]
    return templates.TemplateResponse(request, 'agent_review.html', {'request':request,'user':user,'active':'agent','ctx':ctx,'agents':agents})

@app.get('/staff/risk')
def risk(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    df=queue_df().head(100).to_dict('records')
    return templates.TemplateResponse(request, 'risk.html', {'request':request,'user':user,'active':'risk','rows':df,'m':metrics()})

@app.get('/staff/human-review')
def human_review(request: Request):
    return staff_queue(request, status='Manual Review Required')

@app.get('/staff/notifications')
def notifications(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    examples=[{'to':'customer','title':'KYC approved','body':'Your KYC verification has been approved.'},{'to':'customer','title':'Document re-upload required','body':'Please upload a clearer salary slip/address proof.'},{'to':'staff','title':'Manual review assigned','body':'A case with two discrepancies requires review.'}]
    return templates.TemplateResponse(request, 'notifications.html', {'request':request,'user':user,'active':'notifications','examples':examples})

@app.get('/staff/audit')
def audit(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    hist=load_data()['history'].head(50).to_dict('records')
    return templates.TemplateResponse(request, 'audit.html', {'request':request,'user':user,'active':'audit','hist':hist})

@app.get('/staff/closure')
def closure(request: Request):
    user=require_login(request)
    if not user or user['role']!='staff': return RedirectResponse('/',303)
    rows=queue_df().tail(40).to_dict('records')
    return templates.TemplateResponse(request, 'closure.html', {'request':request,'user':user,'active':'closure','rows':rows})

@app.get('/customer/dashboard')
def customer_dashboard(request: Request):
    user=require_login(request)
    if not user or user['role']!='customer': return RedirectResponse('/',303)
    ctx=customer_context(user['customer_id'])
    return templates.TemplateResponse(request, 'customer_dashboard.html', {'request':request,'user':user,'active':'customer_dashboard',**ctx})

@app.get('/customer/register')
def register_page(request: Request):
    user=get_user(request) or {'role':'guest','name':'New Applicant'}
    return templates.TemplateResponse(request, 'register.html', {'request':request,'user':user,'active':'register'})

@app.post('/customer/register')
def register_customer(request: Request, full_name: str=Form(...), email: str=Form(...), mobile: str=Form(...), dob: str=Form(...), gender: str=Form(...), address: str=Form(...), city: str=Form(...), state: str=Form(...), occupation: str=Form(...), income_range: str=Form(...), policy: str=Form('Standard Onboarding')):
    customers=read_csv('customers.csv')
    n=len(customers)+1
    cid=f'CUST{n:04d}'; case=f'CASE{n:04d}'; username=f'cust{n:04d}'
    status_map={'Low Risk - Straight Through Processing':'Approved','Identity Review - Single Data Mismatch':'Manual Review Required','Enhanced Due Diligence - Two Data Mismatches':'Manual Review Required','Document Remediation - Missing Mandatory Document':'More Documents Required','Standard Onboarding - AI Risk Assessment':'Manual Review Required'}
    new={'case_id':case,'customer_id':cid,'login_username':username,'full_name':full_name,'dob':dob,'gender':gender,'email':email,'mobile':mobile,'address':address,'city':city,'state':state,'country':'India','nationality':'Indian','occupation':occupation,'income_range':income_range,'customer_type':'Retail','application_channel':'Customer Portal','application_date':datetime.now().date().isoformat(),'case_status':status_map.get(policy,'Manual Review Required'),'assigned_queue':'Onboarding Queue','sla_hours':72,'synthetic_risk_profile':'Low','profile_image_path':'uploads/customer_uploaded_documents/.gitkeep'}
    customers=pd.concat([customers, pd.DataFrame([new])], ignore_index=True)
    customers.to_csv(BASE/'data'/'customers.csv', index=False)
    request.session['last_registered']={'case_id':case,'customer_id':cid,'username':username,'password':'Trust@123'}
    return RedirectResponse('/customer/upload',303)

@app.get('/customer/upload')
def upload_page(request: Request):
    user=get_user(request) or {'role':'guest','name':'New Applicant'}
    last=request.session.get('last_registered')
    return templates.TemplateResponse(request, 'upload.html', {'request':request,'user':user,'active':'upload','last':last})

@app.post('/customer/upload')
async def upload_docs(request: Request, files: list[UploadFile]=File(default=[])):
    last=request.session.get('last_registered') or {'customer_id':'NEW'}
    out=BASE/'uploads'/'customer_uploaded_documents'/last.get('customer_id','NEW')
    out.mkdir(parents=True, exist_ok=True)
    saved=[]
    for f in files:
        if f.filename:
            dest=out/f.filename
            with dest.open('wb') as w: shutil.copyfileobj(f.file,w)
            saved.append(f.filename)
    return templates.TemplateResponse(request, 'upload.html', {'request':request,'user':get_user(request) or {'role':'guest','name':'New Applicant'},'active':'upload','last':last,'saved':saved})

@app.get('/media/{path:path}')
def media(path:str):
    p=BASE/path
    if p.exists(): return FileResponse(p)
    return JSONResponse({'error':'not found'},404)

def fallback_answer(user, q):
    ql=q.lower(); d=load_data(); m=metrics()
    if user and user.get('role')=='customer':
        ctx=customer_context(user.get('customer_id'))
        if not ctx: return 'I could not find your customer case. Please contact support.'
        cust=ctx['cust']
        if 'status' in ql or 'kyc' in ql: return f"Your KYC status is {ctx['decision']} for case {cust['case_id']}."
        if 'document' in ql or 'upload' in ql: return f"I found {len(ctx['files'])} document records for your case. Required documents include PAN, Aadhaar, bank statement, salary slip and address proof."
        if 'review' in ql or 'why' in ql: return f"Your case is routed based on discrepancy count and risk checks. Current issue count: {ctx['discrepancy']}."
        return f"I can help with your KYC status, required documents, upload steps and review reason. Your case ID is {cust['case_id']}."
    if 'count' in ql or 'customer' in ql or 'total' in ql: return f"Portfolio summary: {m.get('total',0)} customers, {m.get('approved',0)} approved, {m.get('review',0)} in manual review, {m.get('docs',0)} awaiting documents and {m.get('rejected',0)} rejected."
    if 'rule' in ql or 'approve' in ql: return 'Decision rule: 0 discrepancy = approve, 1-2 discrepancies = manual review, missing mandatory document = document remediation, more than 2 discrepancies = reject/escalate.'
    if 'manual' in ql or 'review' in ql: return f"There are {m.get('review',0)} manual review cases. Open Case Queue and filter Manual Review Required."
    if 'risk' in ql: return f"High-risk cases are identified using risk profile, document quality, identity match, sanctions/PEP/adverse media and fraud signals. Current high-risk count: {m.get('high',0)}."
    return 'I can help staff with case queues, approval rules, customer profile checks, risk summary, document issues, notifications and audit trail.'

@app.post('/api/chat')
async def chat_api(request: Request):
    user=get_user(request) or {'role':'guest'}
    data=await request.json(); question=data.get('question','')[:1000]
    answer=None
    if API_KEY:
        try:
            from google import genai
            client=genai.Client(api_key=API_KEY)
            role='customer' if user.get('role')=='customer' else 'staff'
            ctx=f"You are TrustShield AI Assistant for {role}. Answer only based on KYC app context. Be concise and professional. Do not expose staff data to customers. User: {user}. Metrics: {metrics()}."
            resp=client.models.generate_content(model=MODEL, contents=ctx+'\nQuestion: '+question)
            answer=resp.text
        except Exception:
            answer=None
    return {'answer': answer or fallback_answer(user,question)}
