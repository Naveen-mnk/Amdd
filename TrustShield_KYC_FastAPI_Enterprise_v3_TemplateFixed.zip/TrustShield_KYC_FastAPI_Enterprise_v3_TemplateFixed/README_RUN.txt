TrustShield KYC FastAPI Enterprise v3 - Template Fixed

Run:
python -m pip install -r requirements.txt
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8501

Open local browser:
http://localhost:8501/

AMD Cloud:
/proxy/8501/

Login:
staff / Trust@123
cust001 / Trust@123
cust010 / Trust@123
cust500 / Trust@123
cust1000 / Trust@123

Notes:
- Use 0.0.0.0 only in the run command, not in browser.
- Fixed TemplateResponse compatibility for latest FastAPI/Starlette.
- Streamlit compatibility health routes added to avoid confusing _stcore 404 logs.
